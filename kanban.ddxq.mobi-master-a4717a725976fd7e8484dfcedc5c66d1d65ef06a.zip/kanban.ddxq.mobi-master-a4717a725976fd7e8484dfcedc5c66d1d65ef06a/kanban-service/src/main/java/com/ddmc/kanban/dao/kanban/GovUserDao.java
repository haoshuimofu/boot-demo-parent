package com.ddmc.kanban.dao.kanban;

import com.ddmc.kanban.dao.base.BaseMysqlDao;
import com.ddmc.kanban.model.login.gov.GovUser;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * 政府用户
 */
@Repository
public interface GovUserDao extends BaseMysqlDao<GovUser, Integer> {

    /**
     * 政府用户
     *
     * @param username 用户名
     * @return
     */
    GovUser findByUsername(@Param("username") String username);

}