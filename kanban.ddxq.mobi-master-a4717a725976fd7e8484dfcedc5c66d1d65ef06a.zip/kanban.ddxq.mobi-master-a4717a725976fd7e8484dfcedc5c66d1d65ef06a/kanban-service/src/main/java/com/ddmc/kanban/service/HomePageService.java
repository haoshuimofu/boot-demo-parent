package com.ddmc.kanban.service;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.homePage.response.OrderHotResponseVo;
import com.ddmc.kanban.response.maicai.ServiceStationResponseVo;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/22
 * @summary
 */
public interface HomePageService {

    /**
     * 获取服务站列表接口  从买菜后台获取数据
     *
     * @param area 区域  默认上海
     * @return
     * @throws Exception
     */
    ResponseBaseVo<List<ServiceStationResponseVo>> getStationList(String area);

    /**
     * 调用php端接口获取数据
     *
     * @return
     * @throws Exception
     */
    ResponseBaseVo<OrderHotResponseVo> getOrderHotMap() throws Exception;

}
