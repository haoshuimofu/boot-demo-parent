package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.constant.ErrorCodeConstants;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.web.WebAttributes;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 */
@Controller
@RequestMapping(value = "api/gov")
public class LoginController {

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public String login() {
        return "login";
    }

    @RequestMapping(value = "/loginfailure")
    @ResponseBody
    public ResponseBaseVo loginfailure(HttpServletRequest request, HttpServletResponse response) {
        Exception exception = (Exception) request.getAttribute(WebAttributes.AUTHENTICATION_EXCEPTION);
        String errorItem = null;
        if(exception instanceof BadCredentialsException){
            errorItem = "用户密码错误！";
        }else if(exception instanceof UsernameNotFoundException) {
            errorItem = "用户不存在！";
        }else{
            errorItem = "";
        }
        return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_101.getErrorCode(),errorItem + ErrorCodeConstants.ERROR_CODE_101.getErrorMsg() );
    }

    @RequestMapping(value = "/logoutSuccess")
    @ResponseBody
    public ResponseBaseVo logoutSuccess(HttpServletRequest request, HttpServletResponse response) {
        return ResponseBaseVo.ok();
    }

}