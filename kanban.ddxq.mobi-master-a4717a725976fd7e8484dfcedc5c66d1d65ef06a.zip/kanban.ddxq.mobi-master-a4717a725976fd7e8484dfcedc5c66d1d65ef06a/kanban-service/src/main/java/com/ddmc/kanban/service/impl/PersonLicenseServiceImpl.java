package com.ddmc.kanban.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.personlicense.PersonLicenseClient;
import com.ddmc.kanban.client.personlicense.response.StationUserResponseVo;
import com.ddmc.kanban.service.PersonLicenseService;
import com.ddmc.kanban.util.JsonUtils;
import com.ddmc.kanban.util.PersonLicenseUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/20
 * @summary
 */
@Service
public class PersonLicenseServiceImpl implements PersonLicenseService {

    private static final Logger logger = LoggerFactory.getLogger(PersonLicenseServiceImpl.class);

    @Autowired
    private PersonLicenseClient personLicenseClient;

    @Override
    public ResponseBaseVo<List<String>> getStationList(String appId, String sign, String area) {
        try {
            String jsonString = personLicenseClient.getStationList(appId, sign, area);
            JSONObject jsonObject = JSONObject.parseObject(jsonString);
            Integer code = jsonObject.getInteger("code");
            if (code != null && code.equals(0)) {
                List<String> lists = (List<String>) jsonObject.get("data");
                if (lists != null) {
                    return ResponseBaseVo.ok(lists);
                }
            }
        } catch (Exception e) {
            logger.error("PersonLicenseServiceImpl.getStationList error ", e);
        }
        return null;
    }

    @Override
    public ResponseBaseVo<StationUserResponseVo> getUser(String appId, String sign, String area, String station, Integer page, Integer rows) {
        try {
            String jsonString = personLicenseClient.getUser(appId, sign, area, station, page, rows);
            Object convertObj = JsonUtils.convert(jsonString);
            JSONObject jsonObject = (JSONObject) convertObj;
            Integer code = jsonObject.getInteger("code");
            if (code != null && code.equals(0) && !StringUtils.isBlank(jsonObject.get("data").toString())) {
                StationUserResponseVo stationUserResponseVo = JSONObject.parseObject(jsonObject.get("data").toString(), StationUserResponseVo.class);
                PersonLicenseUtil.setStatus(stationUserResponseVo.getList());
                return ResponseBaseVo.ok(stationUserResponseVo);
            }
        } catch (Exception e) {
            logger.error("PersonLicenseServiceImpl.getUser error ", e);
        }
        return null;
    }
}
