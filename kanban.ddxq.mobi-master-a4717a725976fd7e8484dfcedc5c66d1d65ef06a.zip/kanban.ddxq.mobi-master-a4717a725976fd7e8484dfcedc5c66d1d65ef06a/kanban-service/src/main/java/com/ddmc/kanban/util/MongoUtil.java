package com.ddmc.kanban.util;

import org.bson.types.ObjectId;

/**
 * MongoDB工具类
 *
 * @Author wude
 * @Create 2019-02-24 13:51
 */
public class MongoUtil {

    /**
     * 生成MongoDB id
     *
     * @return
     */
    public static String generateMongoId() {
        return new ObjectId().toHexString();
    }

    /**
     * 生成MongoDB id
     *
     * @return
     */
    public static ObjectId generateMongoObjectId() {
        return new ObjectId();
    }
}