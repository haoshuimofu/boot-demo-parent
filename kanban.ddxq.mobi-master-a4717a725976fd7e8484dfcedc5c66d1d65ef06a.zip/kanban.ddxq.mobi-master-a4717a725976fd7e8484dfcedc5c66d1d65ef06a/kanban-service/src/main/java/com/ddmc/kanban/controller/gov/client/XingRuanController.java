package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.XingRuanClient;
import com.ddmc.kanban.request.DataLoginRequestVo;
import com.ddmc.kanban.response.DataLoginResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
@RestController
@RequestMapping(value = "api/gov/xingruan", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE, MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class XingRuanController {

    @Autowired
    private XingRuanClient xingRuanClient;

    @RequestMapping(value = "/GetLoginInfo", method = RequestMethod.POST)
    public ResponseBaseVo<DataLoginResponseVo> getLoginInfo(@RequestBody DataLoginRequestVo dataLoginRequestVo) {
        try {
            DataLoginResponseVo responseVo = xingRuanClient.GetLoginInfo(dataLoginRequestVo);
            if (responseVo != null) {
                return ResponseBaseVo.ok(responseVo);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
