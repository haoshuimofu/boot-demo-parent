package com.ddmc.kanban.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.homePage.HomePageClient;
import com.ddmc.kanban.client.homePage.response.OrderHotResponseVo;
import com.ddmc.kanban.dao.maicai.ServiceStationDao;
import com.ddmc.kanban.model.maicai.ServiceStation;
import com.ddmc.kanban.response.maicai.ServiceStationResponseVo;
import com.ddmc.kanban.service.HomePageService;
import com.google.common.collect.Lists;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/22
 * @summary
 */
@Service
public class HomePageServiceImpl implements HomePageService {

    private static final Logger logger = LoggerFactory.getLogger(HomePageServiceImpl.class);

    @Autowired
    private ServiceStationDao serviceStationDao;

    @Autowired
    private HomePageClient homePageClient;

    @Override
    public ResponseBaseVo<List<ServiceStationResponseVo>> getStationList(String area) {
        List<ServiceStation> serviceStations = serviceStationDao.queryByArea(area);
        if (serviceStations != null && serviceStations.size() > 0) {
            List<ServiceStationResponseVo> list = Lists.newArrayList();
            for (ServiceStation station : serviceStations) {
                ServiceStationResponseVo stationResponseVo = new ServiceStationResponseVo();
                stationResponseVo.setStationId(station.getId());
                stationResponseVo.setStationName(station.getName());
                stationResponseVo.setStationAddress(station.getAddress());
                list.add(stationResponseVo);
            }
            return ResponseBaseVo.ok(list);
        }
        return null;
    }

    @Override
    public ResponseBaseVo<OrderHotResponseVo> getOrderHotMap() throws Exception {
        try {
            String jsonString = homePageClient.getOrderHotMap();
            JSONObject jsonObject = JSONObject.parseObject(jsonString);
            Integer code = jsonObject.getInteger("code");
            if (code != null && code.equals(0) && !StringUtils.isBlank(jsonObject.get("data").toString())) {
                OrderHotResponseVo orderHotResponseVo = JSONObject.parseObject(jsonObject.get("data").toString(), OrderHotResponseVo.class);
                if (orderHotResponseVo != null) {
                    return ResponseBaseVo.ok(orderHotResponseVo);
                }
            }
        } catch (Exception e) {
            logger.error("HomePageServiceImpl.getOrderHotMap error ", e);
        }
        return null;
    }
}
