package com.ddmc.kanban.service;

import com.ddmc.core.model.Pagination;
import com.ddmc.kanban.model.yestodayquality.YestodayQualitySummary;
import com.ddmc.kanban.response.YestodayQualityControlDetailVo;
import com.ddmc.kanban.response.YestodayQualityControlVo;

public interface YestodayQualityService {

	/**
	 * 
	 * @return
	 */
	YestodayQualitySummary getFirstSummary();

	/**
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws Exception 
	 */
	Pagination<YestodayQualityControlVo> getPageList(Integer page, Integer pageSize) throws Exception;

	/**
	 * @param qualityId
	 * @return
	 */
	YestodayQualityControlDetailVo getDetail(Long qualityId);
	
	int batchHandler();

}
