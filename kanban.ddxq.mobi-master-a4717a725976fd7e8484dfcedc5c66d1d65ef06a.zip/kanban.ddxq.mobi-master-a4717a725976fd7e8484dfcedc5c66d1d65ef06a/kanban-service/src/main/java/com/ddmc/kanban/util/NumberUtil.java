package com.ddmc.kanban.util;

import java.math.BigDecimal;

/**
 * 数字工具类
 *
 * @Author wude
 * @Create 2019-02-19 18:41
 */
public class NumberUtil {

    public static double format(double num, int scale) {
        return scale <= 0 ? num : BigDecimal.valueOf(num).setScale(scale, BigDecimal.ROUND_DOWN).doubleValue();
    }
}