package com.ddmc.sso.client.service;

import com.ddmc.sso.client.vo.request.AuthRequestVo;
import com.ddmc.sso.client.vo.response.UserInfoResponseVo;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface AdminService {

    /**
     * sso 授权认证
     * @param request
     * @param response
     * @param authRequestVo
     * @return
     */
    public UserInfoResponseVo auth(HttpServletRequest request, HttpServletResponse response, AuthRequestVo authRequestVo);

    /**
     * 校验登录用户是否有权访问某个URL
     * @return
     */
    public boolean checkAccess(HttpServletRequest request, HttpServletResponse response);

    /**
     * 获取登录信息
     * @param request
     * @param response
     * @return
     */
    public AuthRequestVo getSession(HttpServletRequest request, HttpServletResponse response);

    /**
     * 获取登录页面URL
     * @return
     */
    public String getLoginUrl();

    /**
     * 禁止访问信息URL
     * @return
     */
    public String getForbiddenUrl();

    public String getIndexUrl();

    public String getForceLoginUrls();

    public String getUrlPatterns();

    /**
     * 退出登录
     * @param request
     * @param response
     */
    public void loginOut(HttpServletRequest request, HttpServletResponse response);
}
