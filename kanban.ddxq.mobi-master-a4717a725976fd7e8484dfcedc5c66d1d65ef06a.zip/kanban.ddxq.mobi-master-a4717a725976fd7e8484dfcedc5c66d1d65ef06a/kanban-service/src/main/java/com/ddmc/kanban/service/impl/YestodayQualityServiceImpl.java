package com.ddmc.kanban.service.impl;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.javassist.expr.NewArray;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ddmc.core.model.Pagination;
import com.ddmc.kanban.dao.kanban.YestodayQualityControlBatchDao;
import com.ddmc.kanban.dao.kanban.YestodayQualitySummaryDao;
import com.ddmc.kanban.model.yestodayquality.YestodayQualityControlBatch;
import com.ddmc.kanban.model.yestodayquality.YestodayQualityControlDetail;
import com.ddmc.kanban.model.yestodayquality.YestodayQualitySummary;
import com.ddmc.kanban.response.YestodayQualityControlDetailVo;
import com.ddmc.kanban.response.YestodayQualityControlVo;
import com.ddmc.kanban.service.YestodayQualityService;
import com.ddmc.kanban.util.DateTimeUtil;
import com.ddmc.kanban.util.UUIdUtil;

@Service
public class YestodayQualityServiceImpl implements YestodayQualityService {

	private static final Logger logger = LoggerFactory.getLogger(YestodayQualityServiceImpl.class);

	private final YestodayQualityControlBatchDao yestodayQualityControlBatchDao;

	private final YestodayQualitySummaryDao yestodayQualitySummaryDao;
	

	@Value("${kanban.yestodayquality.cityid}")
	public String cityId;

	public YestodayQualityServiceImpl(YestodayQualityControlBatchDao yestodayQualityControlBatchDao,
			YestodayQualitySummaryDao yestodayQualitySummaryDao) {
		this.yestodayQualityControlBatchDao = yestodayQualityControlBatchDao;
		this.yestodayQualitySummaryDao = yestodayQualitySummaryDao;
	}

	/**
	 * 查詢最新的一條summary記錄
	 */
	@Override
	public YestodayQualitySummary getFirstSummary() {
		return yestodayQualitySummaryDao.queryNewest();
	}

	/**
	 * 查询列表展示
	 * @param page
	 * @param pageSize
	 * @return
	 * @throws ParseException
	 */
	@Override
	public Pagination<YestodayQualityControlVo> getPageList(Integer page, Integer pageSize) throws Exception {
		Pagination<YestodayQualityControlVo> result = new Pagination<>();
		try {

			result.setPage(page.longValue());
			result.setPageSize(pageSize.longValue());
			Integer totalCount = yestodayQualityControlBatchDao.getPageListCount();
			result.setTotalRecords(totalCount.longValue());
			List<YestodayQualityControlBatch> list = null;
			if (totalCount > 0) {
				list = yestodayQualityControlBatchDao.getPageList(result.getStartIndex(), pageSize);
			}
			if (list != null && !list.isEmpty()) {
				List<YestodayQualityControlVo> voList = new ArrayList<>();
				for (YestodayQualityControlBatch batch : list) {
					YestodayQualityControlVo vo = convertToControlVo(batch);
					voList.add(vo);
				}
				result.setModels(voList);
			}
		} catch (ParseException e) {
			logger.error("yestodayQualityService getPageList error", e);
			throw e;
		}
		return result;

	}

	/**
	 * 查询详情
	 * @param qualityId
	 * @return
	 */
	@Override
	public YestodayQualityControlDetailVo getDetail(Long qualityId) {
		YestodayQualityControlDetail detail = yestodayQualityControlBatchDao.queryDetailByQualityId(qualityId);
		return convertToControlDetailVo(detail);
	}

	/**
	 * @param yestodayQualityControlBatch
	 * @return
	 * @throws ParseException
	 */
	private YestodayQualityControlVo convertToControlVo(YestodayQualityControlBatch batch) throws ParseException {
		if (batch != null) {
			YestodayQualityControlVo vo = new YestodayQualityControlVo();
			vo.setPurchaseId(batch.getPurchaseId());
			vo.setProductName(batch.getProductName());
			vo.setQualityId(batch.getQualityId());
			vo.setQualityJudgment(batch.getQualityJudgment());
			String qualityTimeStr = DateTimeUtil.dateFormat(batch.getQualityTime(), DateTimeUtil.DATE_TIME_PATTERN);
			vo.setQualityTime(qualityTimeStr);
			vo.setReceptionType(batch.getReceptionType());
			return vo;
		}
		return null;
	}

	/**
	 * @param detail
	 * @return
	 */
	private YestodayQualityControlDetailVo convertToControlDetailVo(YestodayQualityControlDetail detail) {
		if (detail != null) {
			YestodayQualityControlDetailVo vo = new YestodayQualityControlDetailVo();
			vo.setProductId(detail.getProductId());
			vo.setProductName(detail.getProductName());
			vo.setPlanAmount(detail.getPlanAmount().toString());
			vo.setRealAmount(detail.getRealAmount().toString());
			vo.setSettlementAmount(detail.getSettlementAmount().toString());
			vo.setSamplingQuantity(detail.getSamplingQuantity());
			vo.setSamplingRate(detail.getSamplingRate());
			vo.setSizeInconformity(detail.getSizeInconformity());
			vo.setOneUnqualified(detail.getOneUnqualified());
			vo.setTwoUnqualified(detail.getTwoUnqualified());
			vo.setThreeUnqualified(detail.getThreeUnqualified());
			vo.setFourUnqualified(detail.getFourUnqualified());
			vo.setUnqualifiedRate(detail.getUnqualifiedRate());
			vo.setCableTicket(detail.getCableTicket());
			vo.setTicketNumber(detail.getTicketNumber());
			vo.setQualityJudgment(detail.getQualityJudgment());
			vo.setReceptionType(detail.getReceptionType());
			vo.setInspector(detail.getInspector());
			return vo;
		}
		return null;
	}

	/**
	 * 查询昨日应质检商品种类数据、并统计应质检数、未质检数、质检不合格数
	 */
	@Transactional
	@Override
	public int batchHandler() {
		try {

			// 起止时间 [昨天0点，今天0点)
			Date startTime = DateTimeUtil.cleanTimeToZero(DateTimeUtil.addDays(new Date(), -1));
			Date endTime = DateTimeUtil.cleanTimeToZero(new Date());
			//查询昨日应质检-未质检数据
			List<YestodayQualityControlBatch> unQualitylist = yestodayQualityControlBatchDao.queryYestodayUnQualityData(cityId,startTime,endTime);
			//查询昨日应质检 -质检不通过数据
			List<YestodayQualityControlBatch> unQualifiedlist = yestodayQualityControlBatchDao.queryYestodayUnQualifiedData(cityId,startTime,endTime);
			//查询昨日应质检 -质检通过数据
			List<YestodayQualityControlBatch> qualifiedlist = yestodayQualityControlBatchDao.queryYestodayQualifiedData(cityId,startTime,endTime);
			
			// 应质检数查询 
			int totalCount = 0 ;
			// 未质检数 
			int unQualityCount = 0; 
			// 质检不合格数 
			int unQualifiedCount = 0;
			// 昨日应质检数据
			List<YestodayQualityControlBatch> list = new ArrayList<>();
			if(null != unQualitylist && !unQualitylist.isEmpty()) {
				unQualityCount = unQualitylist.size(); //未质检数
				totalCount += unQualityCount; //总数上加未质检数
				list.addAll(unQualitylist);   //加入list
			}
			if(null != unQualifiedlist && !unQualifiedlist.isEmpty()) {
				unQualifiedCount = unQualifiedlist.size(); //未质检数
				totalCount += unQualifiedCount; //总数上加未通过检数
				list.addAll(unQualifiedlist);   //加入list
			}
			if(null != qualifiedlist && !qualifiedlist.isEmpty()) {
				totalCount += qualifiedlist.size(); //总数上加通过检数
				list.addAll(qualifiedlist);
				
			}
			
			// 生成批次号
			String batchId = UUIdUtil.getSixteenUUId();
			// 保存应质检数据
			if (null != list && !list.isEmpty()) {
				//应质检数据转化成看板数据 
				transferYestodayData(list,batchId);
				yestodayQualityControlBatchDao.saveList(list);
			}
			
			// 保存summary数据
			YestodayQualitySummary summary = new YestodayQualitySummary();
			summary.setBatchId(batchId);
			summary.setSummaryDate(startTime);
			summary.setTotalCount(totalCount);
			summary.setUnQualityCount(unQualityCount);
			summary.setUnQualifiedCount(unQualifiedCount);
			yestodayQualitySummaryDao.save(summary);
			
			// 查询原batchId
			String originalBatchId = yestodayQualityControlBatchDao.queryCurrentBatchId();
			// 将之前的数据改为不显示
			yestodayQualityControlBatchDao.updateOldDataHidden(originalBatchId);

			return totalCount;
		} catch (Exception e) {
			logger.error("YestodayQuality batchHandle error", e);
			throw e;
		}
	}

	/**
	 * 将应质检数据转化成看板数据
	 * 
	 * @param list
	 */
	public void transferYestodayData(List<YestodayQualityControlBatch> list,String batchId) {

		if (null != list && !list.isEmpty()) {
			
			for (YestodayQualityControlBatch batch : list) {
				batch.setBatchId(batchId);
				if (null == batch.getQualityId() || 0L == batch.getQualityId()) {
					batch.setQualityId(0L);
					batch.setQualityJudgment(-1); // 未质检的数据为-1
					batch.setReceptionType(-1); // 未入库的数据为-1
					batch.setQualityTime(null);
				}
			}
		}

	}

}
