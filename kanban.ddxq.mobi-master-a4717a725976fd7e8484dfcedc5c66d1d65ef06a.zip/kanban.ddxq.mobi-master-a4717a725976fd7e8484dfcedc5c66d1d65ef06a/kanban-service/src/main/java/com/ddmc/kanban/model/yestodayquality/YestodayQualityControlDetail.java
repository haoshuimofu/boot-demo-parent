package com.ddmc.kanban.model.yestodayquality;

import java.math.BigDecimal;

public class YestodayQualityControlDetail {

	private Long productId;

	private String productName;

	private BigDecimal planAmount;

	private BigDecimal realAmount;

	private BigDecimal settlementAmount;

	private BigDecimal samplingQuantity;

	private BigDecimal samplingRate;

	private BigDecimal sizeInconformity;

	private BigDecimal oneUnqualified;

	private BigDecimal twoUnqualified;

	private BigDecimal threeUnqualified;
	
	private BigDecimal fourUnqualified;

	private BigDecimal unqualifiedRate;

	private String cableTicket;

	private String ticketNumber;

	private Integer qualityJudgment;

	private Integer receptionType;

	private String inspector;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public BigDecimal getPlanAmount() {
		return planAmount;
	}

	public void setPlanAmount(BigDecimal planAmount) {
		this.planAmount = planAmount;
	}

	public BigDecimal getRealAmount() {
		return realAmount;
	}

	public void setRealAmount(BigDecimal realAmount) {
		this.realAmount = realAmount;
	}

	public BigDecimal getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(BigDecimal settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public BigDecimal getSamplingQuantity() {
		return samplingQuantity;
	}

	public void setSamplingQuantity(BigDecimal samplingQuantity) {
		this.samplingQuantity = samplingQuantity;
	}

	public BigDecimal getSamplingRate() {
		return samplingRate;
	}

	public void setSamplingRate(BigDecimal samplingRate) {
		this.samplingRate = samplingRate;
	}

	public BigDecimal getSizeInconformity() {
		return sizeInconformity;
	}

	public void setSizeInconformity(BigDecimal sizeInconformity) {
		this.sizeInconformity = sizeInconformity;
	}

	public BigDecimal getOneUnqualified() {
		return oneUnqualified;
	}

	public void setOneUnqualified(BigDecimal oneUnqualified) {
		this.oneUnqualified = oneUnqualified;
	}

	public BigDecimal getTwoUnqualified() {
		return twoUnqualified;
	}

	public void setTwoUnqualified(BigDecimal twoUnqualified) {
		this.twoUnqualified = twoUnqualified;
	}

	public BigDecimal getThreeUnqualified() {
		return threeUnqualified;
	}

	public void setThreeUnqualified(BigDecimal threeUnqualified) {
		this.threeUnqualified = threeUnqualified;
	}

	public BigDecimal getFourUnqualified() {
		return fourUnqualified;
	}

	public void setFourUnqualified(BigDecimal fourUnqualified) {
		this.fourUnqualified = fourUnqualified;
	}

	public BigDecimal getUnqualifiedRate() {
		return unqualifiedRate;
	}

	public void setUnqualifiedRate(BigDecimal unqualifiedRate) {
		this.unqualifiedRate = unqualifiedRate;
	}

	public String getCableTicket() {
		return cableTicket;
	}

	public void setCableTicket(String cableTicket) {
		this.cableTicket = cableTicket;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public Integer getQualityJudgment() {
		return qualityJudgment;
	}

	public void setQualityJudgment(Integer qualityJudgment) {
		this.qualityJudgment = qualityJudgment;
	}

	public Integer getReceptionType() {
		return receptionType;
	}

	public void setReceptionType(Integer receptionType) {
		this.receptionType = receptionType;
	}

	public String getInspector() {
		return inspector;
	}

	public void setInspector(String inspector) {
		this.inspector = inspector;
	}

}
