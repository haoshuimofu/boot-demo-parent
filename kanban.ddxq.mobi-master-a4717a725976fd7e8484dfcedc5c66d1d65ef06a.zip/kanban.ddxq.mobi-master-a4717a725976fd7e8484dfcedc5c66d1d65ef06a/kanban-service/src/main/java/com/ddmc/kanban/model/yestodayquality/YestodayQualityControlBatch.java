package com.ddmc.kanban.model.yestodayquality;

import java.util.Date;

/**
 * 
* <p>Description: </p>    
* @author chenkai  
* @date 2019年3月19日
 */
public class YestodayQualityControlBatch {
	
	private Long id;
	
	private String batchId;
	
	private Long productId;
	
	private String productName;
	
	private Long purchaseId;
	
	private Long qualityId;
	
	private Integer qualityJudgment;
	
	private Integer receptionType;
	
	private Date qualityTime;
	
	private Integer showStatus;
	
	private Date createTime;
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getQualityId() {
		return qualityId;
	}

	public void setQualityId(Long qualityId) {
		this.qualityId = qualityId;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Long getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(Long purchaseId) {
		this.purchaseId = purchaseId;
	}

	public Integer getQualityJudgment() {
		return qualityJudgment;
	}

	public void setQualityJudgment(Integer qualityJudgment) {
		this.qualityJudgment = qualityJudgment;
	}

	public Integer getReceptionType() {
		return receptionType;
	}

	public void setReceptionType(Integer receptionType) {
		this.receptionType = receptionType;
	}

	public Date getQualityTime() {
		return qualityTime;
	}

	public void setQualityTime(Date qualityTime) {
		this.qualityTime = qualityTime;
	}

	public Integer getShowStatus() {
		return showStatus;
	}

	public void setShowStatus(Integer showStatus) {
		this.showStatus = showStatus;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	
	
}
