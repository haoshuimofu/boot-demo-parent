package com.ddmc.kanban.service;

import com.ddmc.core.model.Pagination;
import com.ddmc.kanban.response.product.monitor.ProductMonitorItemResponseVo;
import com.ddmc.kanban.response.product.monitor.ProductMonitorSummaryResponseVo;

import java.util.Date;

/**
 * 商品临期过期监控S
 *
 * @Author wude
 * @Create 2019-03-18 17:33
 */
public interface ProductMonitorService {

    /**
     * 把scm.store_product_batch表中临期过期记录抽取到kanban.store_product_batch_temp
     *
     * @return
     * @throws Exception
     */
    Date syncStoreProductBatch() throws Exception;

    /**
     * kanban.store_product_batch_temp中临期过期商品批次记录抽取门店过期临期商品数，其实就是批次合并
     *
     * @param time
     */
    void syncStoreProductBatchTemp2StoreProductMonitor(Date time);

    /**
     * 临期过期商品监控总览
     *
     * @return
     */
    ProductMonitorSummaryResponseVo getProductMonitorySummary() throws Exception;

    /**
     * 分页查询临期或过期商品列表数据
     *
     * @param type
     * @param page
     * @param pageSize
     * @return
     */
    Pagination<ProductMonitorItemResponseVo> listByType(Integer type, int page, int pageSize);

    void test();

}