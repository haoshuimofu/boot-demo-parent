package com.ddmc.kanban.config;

import com.alibaba.druid.pool.DruidDataSource;
import com.ddmc.sso.client.filter.AdminLoginFilter;
import com.ddmc.sso.client.service.AdminService;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.servlet.Filter;
import javax.sql.DataSource;

/**
 * @author dell
 * @version 1.0.0
 * @create 2018-09-30 13:05
 */
@Configuration
public class AdminSsoConfiguration {
    @Autowired
    private  AdminService adminService;
    /**
     * 配置过滤器
     * @return
     */
    @Bean
    public FilterRegistrationBean someFilterRegistration() {
        if(StringUtils.isBlank(adminService.getUrlPatterns())) {
            return null;
        }
        FilterRegistrationBean registration = new FilterRegistrationBean();
        registration.setFilter(adminLoginFilter());
        registration.addUrlPatterns(adminService.getUrlPatterns().split(","));
        registration.setName("adminLoginFilter");
        return registration;
    }


    /**
     * 创建一个bean
     * @return
     */
    @Bean(name = "adminLoginFilter")
    public Filter adminLoginFilter() {
        return new AdminLoginFilter(adminService);
    }

}