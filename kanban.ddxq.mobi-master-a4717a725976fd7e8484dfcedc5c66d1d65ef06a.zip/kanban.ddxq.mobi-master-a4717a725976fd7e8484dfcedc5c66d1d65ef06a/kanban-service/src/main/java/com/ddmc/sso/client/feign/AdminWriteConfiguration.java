package com.ddmc.sso.client.feign;

import feign.Request;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class AdminWriteConfiguration {

    @Bean
    @Scope("prototype")
    Request.Options feignOptions() {
        return new Request.Options(10 * 1000, 10 * 1000);
    }

}
