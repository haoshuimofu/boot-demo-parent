package com.ddmc.kanban.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.ddmc.core.model.Pagination;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.productsource.ProductSourceClient;
import com.ddmc.kanban.client.productsource.response.ProductSourceResponseVo;
import com.ddmc.kanban.dao.kanban.ProductDao;
import com.ddmc.kanban.service.ProductSourceService;
import com.ddmc.kanban.util.JsonUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/20
 * @summary
 */
@Service
public class ProductSourceServiceImpl implements ProductSourceService {

    private static final Logger logger = LoggerFactory.getLogger(ProductSourceServiceImpl.class);

    @Autowired
    private ProductSourceClient productSourceClient;

    @Autowired
    private ProductDao productDao;

    @Override
    public ResponseBaseVo<Pagination> selectProductName(String productName, Integer page, Integer pageSize) {
        int num = productDao.selectAllByProductName(productName);
        if (page == null || page <= 0) {
            page = 1;
        }
        if (pageSize == null || pageSize < 25) {
            pageSize = 25;
        }
        List<String> list = productDao.selectProductName(productName, (page - 1) * pageSize, pageSize);
        Pagination pagination = new Pagination();
        pagination.setPage(Long.valueOf(page));
        pagination.setPageSize(Long.valueOf(pageSize));
        pagination.setTotalRecords(Long.valueOf(num));
        pagination.setModels(list);
        return ResponseBaseVo.ok(pagination);
    }

    @Override
    public ResponseBaseVo<ProductSourceResponseVo> getSource(String productName, String batchNum) {
        try {
            String jsonString = productSourceClient.source(productName, batchNum);
            Object convertObj = JsonUtils.convert(jsonString);
            JSONObject jsonObject = (JSONObject) convertObj;
            Integer code = jsonObject.getInteger("code");
            if (code != null && code.equals(0) && !StringUtils.isBlank(jsonObject.get("data").toString())) {
                ProductSourceResponseVo productSourceResponseVo = JSONObject.parseObject(jsonObject.get("data").toString(), ProductSourceResponseVo.class);
                return ResponseBaseVo.ok(productSourceResponseVo);
            }
        } catch (Exception e) {
            logger.error("ProductSourceServiceImpl.getSource error ", e);
        }
        return null;
    }
}
