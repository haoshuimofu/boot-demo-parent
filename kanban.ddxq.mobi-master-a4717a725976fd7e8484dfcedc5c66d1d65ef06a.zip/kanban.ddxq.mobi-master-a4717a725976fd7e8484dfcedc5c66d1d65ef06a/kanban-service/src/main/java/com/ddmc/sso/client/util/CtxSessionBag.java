/** 
 *CtxCasSessionBag.java
 * Copyright (C) 2012 YIHAODIAN Inc., All Rights Reserved.
 *
 * 对该类提供的功能，详细用法，使用环境的详细描述
 * 
 */

package com.ddmc.sso.client.util;


import com.ddmc.sso.client.vo.request.AuthRequestVo;

/**
 * 获取session信息工具类，
 */
public class CtxSessionBag {

	private static final ThreadLocal<AuthRequestVo> casSessionBagThread = new ThreadLocal<AuthRequestVo>();
	
	public static AuthRequestVo getCasSessionBag() {
        return casSessionBagThread.get();
    }

    public static void setCasSessionBag(AuthRequestVo user) {
    	casSessionBagThread.set(user);
    }

    /**
	 * 线程内清除
	 */
	public static void clear() {
		casSessionBagThread.set(null);
	}
}
