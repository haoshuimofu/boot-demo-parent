package com.ddmc.kanban.controller.manage;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.constant.ErrorCodeConstants;
import com.ddmc.kanban.request.product.monitor.ProductMonitorListRequestVo;
import com.ddmc.kanban.response.product.monitor.ProductMonitorSummaryResponseVo;
import com.ddmc.kanban.service.ProductMonitorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 商品监控控制器
 *
 * @Author wude
 * @Create 2019-03-18 17:31
 */
@RestController
@RequestMapping(value = "manage/product/monitor", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE, MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class ProductMonitorController {

    private static final Logger logger = LoggerFactory.getLogger(ProductMonitorController.class);

    private final ProductMonitorService productMonitorService;

    public ProductMonitorController(ProductMonitorService productMonitorService) {
        this.productMonitorService = productMonitorService;
    }

    @GetMapping(value = "summary")
    public ResponseBaseVo<ProductMonitorSummaryResponseVo> summary() {
        try {
            return ResponseBaseVo.ok(productMonitorService.getProductMonitorySummary());
        } catch (Exception e) {
            logger.error("获取临期过期商品监控情况出错了!", e);
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_901.getErrorCode(), ErrorCodeConstants.ERROR_CODE_901.getErrorMsg(), null);
        }
    }

    @GetMapping("list")
    public ResponseBaseVo listByType(@RequestBody ProductMonitorListRequestVo request) {
        if (request.getType() == null) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_000.getErrorCode(), ErrorCodeConstants.ERROR_CODE_000.getErrorMsg());
        }
        return ResponseBaseVo.ok(productMonitorService.listByType(request.getType(), request.getPage(), request.getPageSize()));
    }


    @GetMapping(value = "refresh")
    public ResponseBaseVo refresh() throws Exception {
        long start = System.currentTimeMillis();
        List<String> logs = new ArrayList<>();
        Date time = productMonitorService.syncStoreProductBatch();
        logs.add(String.format("Step1: %s", (System.currentTimeMillis() - start) / 1000));
        productMonitorService.syncStoreProductBatchTemp2StoreProductMonitor(time);
        logs.add(String.format("Step2: %s", (System.currentTimeMillis() - start) / 1000));
        logs.forEach(System.out::println);
        return ResponseBaseVo.ok();
    }

    @GetMapping(value = "test")
    public ResponseBaseVo test() throws Exception {
        productMonitorService.test();
        return ResponseBaseVo.ok();
    }

}