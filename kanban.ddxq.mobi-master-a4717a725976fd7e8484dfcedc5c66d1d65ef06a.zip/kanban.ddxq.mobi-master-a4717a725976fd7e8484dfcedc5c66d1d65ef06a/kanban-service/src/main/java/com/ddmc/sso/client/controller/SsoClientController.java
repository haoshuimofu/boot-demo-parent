package com.ddmc.sso.client.controller;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.sso.client.service.AdminService;
import com.ddmc.sso.client.vo.request.AuthRequestVo;
import com.ddmc.sso.client.vo.response.UserInfoResponseVo;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 */
@RestController
@RequestMapping(value = "api/admin/sso")
public class SsoClientController {


    private final AdminService adminService;

    public SsoClientController(AdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping("/auth")
    public void auth(HttpServletRequest request, HttpServletResponse response, AuthRequestVo authRequestVo)  throws IOException, ServletException {
        UserInfoResponseVo userInfoResponseVo = adminService.auth(request, response, authRequestVo);
        if(null==userInfoResponseVo){
            request.getRequestDispatcher(adminService.getForbiddenUrl()).forward(request, response);
        }else{
            response.sendRedirect(adminService.getIndexUrl());
        }
    }

    @RequestMapping(value = "/forbidden",produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseBaseVo forbidden() {
        return  ResponseBaseVo.fail("403" , "您无权访问该服务！");
    }
}