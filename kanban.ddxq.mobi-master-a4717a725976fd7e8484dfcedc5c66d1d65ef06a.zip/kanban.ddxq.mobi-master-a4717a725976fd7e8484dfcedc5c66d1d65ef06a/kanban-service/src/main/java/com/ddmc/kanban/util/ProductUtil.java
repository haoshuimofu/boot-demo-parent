package com.ddmc.kanban.util;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.annotation.JSONField;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Calendar;
import java.util.Date;

/**
 * 商品工具类
 *
 * @Author wude
 * @Create 2019-03-19 16:47
 */
public class ProductUtil {

    /**
     * 一天毫秒数
     */
    private static int ONE_DAY_MILLISECONDS = 24 * 3600 * 1000;

    /**
     * 根据批次和保质期获取商品过期天数
     *
     * @param batchId       批次号，格式为：190319(意为：19年3月19号)
     * @param qualityPeriod 保质期天数，相对批次号开始算起
     * @param date          日期
     * @return
     */
    public static int getExpiredDay(String batchId, Integer qualityPeriod, Date date) throws Exception {
        if (batchId.length() < 6) return 0;
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int batchMonth = Integer.valueOf(batchId.substring(2, 4)) + 1;
        String dateime = String.valueOf(year).substring(0, 2) + batchId;
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 计算日期和批次日期：时分秒毫秒清零
        Date batchDate = DateTimeUtil.cleanTimeToZero(format.parse(dateime));
        Date refDate = DateTimeUtil.cleanTimeToZero(date);
        return (int) ((refDate.getTime() - batchDate.getTime() - qualityPeriod * 24 * 3600 * 1000) / ONE_DAY_MILLISECONDS);
    }

    /**
     * 根据批次和可售期判断商品是否临期
     *
     * @param batchId    批次号，格式为：190319(意为：19年3月19号)
     * @param salePeriod 可售期，相对批次号开始算起
     * @param date       日期
     * @return
     */
    public static boolean isExpiring(String batchId, Integer salePeriod, Date date) throws Exception {
        if (batchId.length() < 6) return false;
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        String dateime = String.valueOf(year).substring(0, 2) + batchId;
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
        // 计算日期和批次日期：时分秒毫秒清零
        Date batchDate = DateTimeUtil.cleanTimeToZero(format.parse(dateime));
        Date refDate = DateTimeUtil.cleanTimeToZero(date);
        return (int) ((refDate.getTime() - batchDate.getTime() - salePeriod * 24 * 3600 * 1000) / ONE_DAY_MILLISECONDS) > 0;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(getExpiredDay("190317", 3, new Date()));
    }

}