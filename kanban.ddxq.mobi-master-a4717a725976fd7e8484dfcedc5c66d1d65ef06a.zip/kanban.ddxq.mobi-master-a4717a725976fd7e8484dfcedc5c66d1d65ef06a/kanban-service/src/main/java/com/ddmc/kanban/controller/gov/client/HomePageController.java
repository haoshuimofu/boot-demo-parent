package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.homePage.response.OrderHotResponseVo;
import com.ddmc.kanban.response.maicai.ServiceStationResponseVo;
import com.ddmc.kanban.service.HomePageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/22
 * @summary 首页 站点查询 热力图 相关功能
 */
@RestController
@RequestMapping(value = "api/gov/homepage", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE, MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class HomePageController {

    @Autowired
    private HomePageService homePageService;

    @RequestMapping(value = "/getStationList", method = RequestMethod.GET)
    public ResponseBaseVo<List<ServiceStationResponseVo>> getStationList(@RequestParam(value = "area", required = false, defaultValue = "上海市") String area) {
        return homePageService.getStationList(area);
    }

    @RequestMapping(value = "/getOrderHotMap", method = RequestMethod.GET)
    public ResponseBaseVo<OrderHotResponseVo> getOrderHotMap() throws Exception {
        return homePageService.getOrderHotMap();
    }

}
