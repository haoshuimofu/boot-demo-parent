package com.ddmc.kanban.constant;

/**
 * Redis Cache Key常量
 *
 * @Author wude
 * @Create 2019-03-06 13:53
 */
public class CacheKeyConstants {

    /**
     * redis里前置仓ID对应的名称
     */
    public static String STORE_NAME_KEY = "kanban:store:name:%s";
}