package com.ddmc.kanban.service.impl;

import com.ddmc.core.model.Pagination;
import com.ddmc.kanban.dao.base.BaseDao;
import com.ddmc.kanban.service.BaseService;
import org.springframework.data.domain.Sort;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class BaseServiceImpl<T> implements BaseService<T> {

    @Override
    public void save(T t) {
        this.getBaseDao().save(t);
    }

    @Override
    public T queryById(String id) {
        return this.getBaseDao().queryById(id);
    }

    @Override
    public List<T> queryList(T object, List<String> selectFields) {
        return this.getBaseDao().queryList(object,selectFields);
    }

    @Override
    public List<T> queryList(T object, LinkedHashMap<String, Sort.Direction> ordersMap, List<String> selectFields) {
        return this.getBaseDao().queryList(object, ordersMap,selectFields);
    }

    @Override
    public T queryOne(T object) {
        return this.getBaseDao().queryOne(object);
    }

    @Override
    public List<T> getPage(T object, Pagination pagination, List<String> selectFields) {
        return this.getBaseDao().getPage(object, pagination,selectFields);
    }

    @Override
    public List<T> getPage(T object, Pagination pagination, LinkedHashMap<String, Sort.Direction> ordersMap, List<String> selectFields) {
        return this.getBaseDao().getPage(object, pagination, ordersMap,selectFields);
    }

    @Override
    public Long getCount(T object) {
        return this.getBaseDao().getCount(object);
    }

    @Override
    public int delete(T t) {
        return this.getBaseDao().delete(t);
    }

    @Override
    public int deleteById(Integer id) {
        return this.getBaseDao().deleteById(id);
    }

    @Override
    public long updateFirst(T srcObj, T targetObj) {
        return this.getBaseDao().updateFirst(srcObj, targetObj);
    }

    @Override
    public long updateMulti(T srcObj, T targetObj) {
        return this.getBaseDao().updateMulti(srcObj, targetObj);
    }

    @Override
    public long updateInsert(T srcObj, T targetObj) {
        return this.getBaseDao().updateInsert(srcObj, targetObj);
    }

    @Override
    public long update(Object id, Map<String, Object> fieldsMap) {
        return this.getBaseDao().update(id,fieldsMap);
    }

    @Override
    public long update(Object id, String field, Object value) {
        return this.getBaseDao().update(id,field,value);
    }

    public abstract BaseDao<T> getBaseDao();

}
