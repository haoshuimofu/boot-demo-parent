package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.model.Pagination;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.productsource.response.ProductSourceResponseVo;
import com.ddmc.kanban.constant.ErrorCodeConstants;
import com.ddmc.kanban.service.ProductSourceService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary 商品溯源
 */
@RestController
@RequestMapping(value = "api/gov/productsource", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE, MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class ProductSourceController {

    @Autowired
    private ProductSourceService productSourceService;

    @RequestMapping(value = "/selectProductName", method = RequestMethod.GET)
    public ResponseBaseVo<Pagination> selectProductName(@RequestParam(value = "productName", required = false) String productName,
                                                        @RequestParam(value = "page", required = false) Integer page,
                                                        @RequestParam(value = "pageSize", required = false) Integer pageSize) {
        if (StringUtils.isBlank(productName)) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_403.getErrorCode(), ErrorCodeConstants.ERROR_CODE_403.getErrorMsg());
        }
        return productSourceService.selectProductName(productName, page, pageSize);
    }


    @RequestMapping(value = "/getSource", method = RequestMethod.GET)
    public ResponseBaseVo<ProductSourceResponseVo> getSource(@RequestParam(value = "productName", required = false) String productName, @RequestParam(value = "batchNum", required = false) String batchNum) {
        if (StringUtils.isBlank(productName)) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_403.getErrorCode(), ErrorCodeConstants.ERROR_CODE_403.getErrorMsg());
        }
        if (StringUtils.isBlank(batchNum)) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_404.getErrorCode(), ErrorCodeConstants.ERROR_CODE_404.getErrorMsg());
        }
        return productSourceService.getSource(productName, batchNum);
    }
}
