package com.ddmc.kanban.dao.maicai.impl;

import com.ddmc.kanban.dao.base.BaseMongoDaoImpl;
import com.ddmc.kanban.dao.maicai.ServiceStationDao;
import com.ddmc.kanban.model.maicai.ServiceStation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/21
 * @summary
 */
@Repository
public class ServiceStationDaoImpl extends BaseMongoDaoImpl<ServiceStation> implements ServiceStationDao {

    @Autowired
    @Qualifier("maicaiMongoTemplate")
    MongoTemplate mongoTemplate;

    @Override
    protected Class getEntityClass() {
        return ServiceStation.class;
    }

    @Override
    public MongoTemplate getMongoTemplate() {
        return mongoTemplate;
    }

    @Override
    public List<ServiceStation> queryByArea(String area) {
        Query query = new Query(Criteria.where("address_city.city_name").regex(area));
        logger.debug(String.format("-------------->MongoDB ServiceStationDaoImpl.queryByCityName() find start,paramas = %s", area));
        return this.getMongoTemplate().find(query, this.getEntityClass());
    }
}
