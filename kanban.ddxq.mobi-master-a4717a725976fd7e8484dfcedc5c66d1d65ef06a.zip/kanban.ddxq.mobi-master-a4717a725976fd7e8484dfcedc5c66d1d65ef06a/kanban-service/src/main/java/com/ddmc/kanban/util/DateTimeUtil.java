package com.ddmc.kanban.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;

/**
 * 时间工具类
 *
 * @Author ddmc
 * @Create 2019-02-24 13:57
 */
public class DateTimeUtil {
	
	public static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
	public static final String MINUTE_PATTERN = "yyyy-MM-dd HH:mm";
	public static final String HOUR_PATTERN = "yyyy-MM-dd HH:mm:ss";
	public static final String DATE_PATTERN = "yyyy-MM-dd";
	public static final String MONTH_PATTERN = "yyyy-MM";
	public static final String YEAR_PATTERN = "yyyy";
	public static final String MINUTE_ONLY_PATTERN = "mm";
	public static final String HOUR_ONLY_PATTERN = "HH";

    /**
     * 获取系统当前的时间秒数
     *
     * @return
     */
    public static Integer getCurrentSecs() {
        return Math.toIntExact(System.currentTimeMillis() / 1000);
    }

    /**
     * 把日期time清零
     *
     * @param date
     * @return
     */
    public static Date cleanTimeToZero(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.set(Calendar.HOUR_OF_DAY, 0);
        calendar.set(Calendar.MINUTE, 0);
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);
        return calendar.getTime();
    }
    
    /**
     * 获取当日剩余秒数
     *
     * @param time
     * @return
     */
    public static Integer getDateTTLSecs(Date time) {
        if (time != null) {
            Date date = cleanTimeToZero(time);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            calendar.add(Calendar.DAY_OF_MONTH, 1);
            return (int) ((calendar.getTime().getTime() - time.getTime()) / 1000);
        }
        return 0;
    }

    /**
     * 获取每天23点59分59秒的时间戳
     *
     * @return 时间戳 秒
     */
    public static int dayTimeTwentythree() {
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String str = sdf.format(date) + " 23:59:59";
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        try {
            date = format.parse(str);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        long timeStemp = date.getTime() / 1000;
        return (int) timeStemp;
    }

    /**
     * 获取精确到秒的时间戳
     *
     * @param date
     * @return
     */
    public static int getSecondTimestamp(Date date) {
        if (null == date) {
            return 0;
        }
        String timestamp = String.valueOf(date.getTime() / 1000);
        return Integer.valueOf(timestamp);
    }

    /**
     * 根据日期获取可能的店铺商品批次
     *
     * @param date
     * @return
     */
    public static int getStoreProductBatchId(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        int year = calendar.get(Calendar.YEAR);
        StringBuilder sb = new StringBuilder(String.valueOf(year).substring(2));
        int month = calendar.get(Calendar.MONTH) + 1;
        sb.append(month >= 10 ? month : "0" + month);
        int day = calendar.get(Calendar.DAY_OF_MONTH);
        sb.append(day >= 10 ? day : "0" + day);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        sb.append(hour >= 10 ? hour : "0" + hour);
        return Integer.valueOf(sb.toString());
    }
    
    /**
     * 日期转化为字符串
     * @param date
     * @param pattern
     * @return
     * @throws ParseException
     */
	public static String dateFormat(Date date, String pattern) throws ParseException {
		if(null == date) {
			return null;
		}
		if (StringUtils.isBlank(pattern)) {
			pattern = DateTimeUtil.DATE_TIME_PATTERN;
		}
		SimpleDateFormat sdf = new SimpleDateFormat(pattern);
		return sdf.format(date);
	}
	
	/**
     * 天数加减
     *
     * @param numDay 要改变的 天数
     * @return
     */
    public static Date addDays(Date date,int numDay) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.DAY_OF_MONTH, numDay);//把日期往后增加一天.整数往后推,负数往前移动
        Date tempDay = calendar.getTime();
        return tempDay;
    }


    public static void main(String[] args) {
        System.out.println(getStoreProductBatchId(new Date()));
    }
}