/**  
* <p>Title: UUIdUtil.java</p>
* <p>Description: </p>    
* @author chenkai  
* @date 2019年3月20日  
*/  
package com.ddmc.kanban.util;

import java.util.Random;
import java.util.UUID;

/**  
* <p>Description: </p>    
* @author chenkai  
* @date 2019年3月20日  
*/
public class UUIdUtil {
	public static String getSixteenUUId() {
        int first = new Random(10).nextInt(8) + 1;
        int hashCodeV = UUID.randomUUID().toString().hashCode();
        if (hashCodeV < 0) {//有可能是负数
            hashCodeV = -hashCodeV;
        }
        // 0 代表前面补充0
        //15代表长度
        // d 代表参数为正数型
        return first + String.format("%015d", hashCodeV);
    }
	public static void main(String[] args) {
		Random r = new Random(10);
		System.out.println(r.nextInt(8) + 1);
		System.out.println(r.nextInt(8) + 1);
		System.out.println(UUIdUtil.getSixteenUUId());
	}
}
