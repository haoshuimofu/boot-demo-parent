package com.ddmc.kanban.service;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.personlicense.response.StationUserResponseVo;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/20
 * @summary
 */
public interface PersonLicenseService {

    /**
     * 调用php服务端获取服务站列表接口
     *
     * @param appId 业务id  required
     * @param sign  签名    required
     * @param area  区域
     * @return
     * @throws Exception
     */
    ResponseBaseVo<List<String>> getStationList(String appId, String sign, String area);

    /**
     * 调用php服务端获取服务站人员接口
     *
     * @param appId   业务id  required
     * @param sign    签名    required
     * @param area    区域
     * @param station 前置仓名称
     * @param page    页数     default 1
     * @param rows    每页行数 default 20
     * @return
     * @throws Exception
     */
    ResponseBaseVo<StationUserResponseVo> getUser(String appId, String sign, String area, String station, Integer page, Integer rows);
}
