package com.ddmc.sso.client.vo.request;

import javax.ws.rs.QueryParam;
import java.io.Serializable;

/**
 * AuthRequestVo
 * r=site/auth&time=1552888051&token=5c1378c66c70ba091b8b8ef4&remember=1&sign=484863787a1ae4150455ecc7dd6b746d
 */
public class AuthRequestVo implements Serializable {
    @QueryParam("sign")
    private String sign ;
    @QueryParam("token")
    private String token ;
    @QueryParam("time")
    private Long time;
    @QueryParam("remember")
    private Integer remember;

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Long getTime() {
        return time;
    }

    public void setTime(Long time) {
        this.time = time;
    }

    public Integer getRemember() {
        return remember;
    }

    public void setRemember(Integer remember) {
        this.remember = remember;
    }
}
