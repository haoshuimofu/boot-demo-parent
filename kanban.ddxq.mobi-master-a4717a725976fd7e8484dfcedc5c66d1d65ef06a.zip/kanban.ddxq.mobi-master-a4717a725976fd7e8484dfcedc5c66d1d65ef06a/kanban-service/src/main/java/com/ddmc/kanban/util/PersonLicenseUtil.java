package com.ddmc.kanban.util;

import com.ddmc.kanban.client.personlicense.response.User;
import com.ddmc.kanban.constant.Constants;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDate;
import java.util.Iterator;
import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
public class PersonLicenseUtil {


    /**
     * 设置status  根据endTime
     * 设置healthImg的前缀 支持公网直接访问
     *
     * @param users
     */
    public static List<User> setStatus(List<User> users) {
        if (users == null) {
            return null;
        }
        for (Iterator<User> iter = users.iterator(); iter.hasNext(); ) {
            User user = iter.next();
            if (StringUtils.isBlank(user.getHealthImg()) || StringUtils.isBlank(user.getHealthEnd())) {
                user.setStatus(Constants.NOT_UPLOADED);
            } else if (LocalDate.now().toString().compareTo(user.getHealthEnd()) <= 0) {
                user.setStatus(Constants.NORMAL);
            } else if (LocalDate.now().toString().compareTo(user.getHealthEnd()) > 0) {
                user.setStatus(Constants.EXPIRE);
            }
        }
        return users;
    }
}
