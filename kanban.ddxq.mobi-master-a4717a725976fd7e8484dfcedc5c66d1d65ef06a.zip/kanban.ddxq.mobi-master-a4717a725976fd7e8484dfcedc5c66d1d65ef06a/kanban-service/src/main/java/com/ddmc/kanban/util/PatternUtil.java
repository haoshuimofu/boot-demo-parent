package com.ddmc.kanban.util;

import java.util.regex.Pattern;

/**
 * @author wangbo
 * @data 2019/2/25
 * @summary
 */
public class PatternUtil {

    private static Pattern MOBILE_PATTERN = Pattern.compile("1[3,4,5,8,7,6,9]\\d{9}|10036\\d{6}|120\\d{8}");
    private static Pattern MOBILE_IS_TRUE = Pattern.compile("/^(10)\\d{9}$/");
    private static Pattern PREG_MATCH = Pattern.compile("/^(10036)\\d{6}$/");


    /**
     * 校验是否是手机号码
     *
     * @param mobile
     * @return
     */
    public static boolean isMobile(String mobile) {
        boolean result = MOBILE_PATTERN.matcher(mobile).matches();
        return result;
    }

    /**
     * 手机号码是否正确
     *
     * @param mobile
     * @return
     */
    public static boolean mobileIsTrue(String mobile) {
        boolean result = MOBILE_IS_TRUE.matcher(mobile).matches();
        return result;
    }

    /**
     * 手机号码是"/^(10036)\d{6}$/"
     *
     * @param mobile
     * @return
     */
    public static boolean pregMatch(String mobile) {
        boolean result = PREG_MATCH.matcher(mobile).matches();
        return result;
    }
}
