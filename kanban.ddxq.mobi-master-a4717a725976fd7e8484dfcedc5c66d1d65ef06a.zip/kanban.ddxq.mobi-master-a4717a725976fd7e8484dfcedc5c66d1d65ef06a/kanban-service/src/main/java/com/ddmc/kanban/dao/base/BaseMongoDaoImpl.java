package com.ddmc.kanban.dao.base;

import com.ddmc.core.model.Pagination;
import com.google.common.collect.Lists;
import org.apache.commons.collections4.MapUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.annotation.Transient;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.util.CollectionUtils;

import java.lang.reflect.Field;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class BaseMongoDaoImpl<T> implements BaseDao<T> {

    protected Logger logger = LoggerFactory.getLogger(BaseMongoDaoImpl.class);

    /**
     * 反射获取泛型类型
     *
     * @return
     */
    protected abstract Class<T> getEntityClass();


    public abstract MongoTemplate getMongoTemplate();

    public void save(T t) {
        logger.debug("-------------->MongoDB save start");
        this.getMongoTemplate().save(t);
    }

    public T queryById(String id) {
        Query query = new Query(Criteria.where("_id").is(id));
        logger.debug("-------------->MongoDB find start");
        return this.getMongoTemplate().findOne(query, this.getEntityClass());
    }

    public List<T> queryList(T object, List<String> selectFields) {
        return this.queryList(object, null, selectFields);
    }


    public List<T> queryList(T object, LinkedHashMap<String, Direction> ordersMap, List<String> selectFields) {
        Query query = getQueryByObject(object);
        restrictQueryFields(query, selectFields);
        this.addSortConditions(query, ordersMap);
        logger.debug("-------------->MongoDB find start");
        return this.getMongoTemplate().find(query, this.getEntityClass());
    }

    public T queryOne(T object) {
        Query query = getQueryByObject(object);
        logger.debug("-------------->MongoDB find start");
        return this.getMongoTemplate().findOne(query, this.getEntityClass());
    }

    public List<T> getPage(T object, Pagination pagination, List<String> selectFields) {
        return this.getPage(object, pagination, null, selectFields);
    }

    public List<T> getPage(T object, Pagination pagination, LinkedHashMap<String, Direction> ordersMap, List<String> selectFields) {
        Query query = getQueryByObject(object);
        //设置查询的字段
        restrictQueryFields(query, selectFields);
        pagination.setTotalRecords(this.getMongoTemplate().count(query, this.getEntityClass()));

        if (0 == pagination.getTotalRecords().compareTo(0L)) {
            return null;
        }
        query.skip(pagination.getStartIndex());
        query.limit(pagination.getPageSize().intValue());

        //设置排序条件
        this.addSortConditions(query, ordersMap);
        logger.debug("-------------->MongoDB queryPage start");
        return this.getMongoTemplate().find(query, this.getEntityClass());
    }

    /**
     * 限定查询的字段
     *
     * @param query
     * @param selectFields
     */
    private void restrictQueryFields(Query query, List<String> selectFields) {
        if (!CollectionUtils.isEmpty(selectFields)) {
            for (String field : selectFields) {
                query.fields().include(field);
            }
        }
    }

    private void addSortConditions(Query query, LinkedHashMap<String, Direction> ordersMap) {
        if (!CollectionUtils.isEmpty(ordersMap)) {
            List<Sort.Order> orders = Lists.newArrayList();  //排序
            for (Map.Entry<String, Direction> entry : ordersMap.entrySet()) {
                orders.add(new Sort.Order(entry.getValue(), entry.getKey()));
            }
            Sort sort = Sort.by(orders);
            query.with(sort);
        }
    }

    public Long getCount(T object) {
        Query query = getQueryByObject(object);
        logger.debug("-------------->MongoDB Count start");
        return this.getMongoTemplate().count(query, this.getEntityClass());
    }

    public int delete(T t) {
        logger.debug("-------------->MongoDB delete start");
        return (int) this.getMongoTemplate().remove(t).getDeletedCount();
    }

    public int deleteById(Object id) {
        Criteria criteria = Criteria.where("_id").is(id);
        if (null != criteria) {
            Query query = new Query(criteria);
            T obj = this.getMongoTemplate().findOne(query, this.getEntityClass());
            logger.debug("-------------->MongoDB deleteById start");
            if (obj != null) {
                return this.delete(obj);
            }
        }
        return 0;
    }

    @Override
    public long update(Object id, T targetObj) {
        Criteria criteria = Criteria.where("_id").is(id);
        if (null != criteria) {
            Query query = new Query(criteria);
            Update update = getUpdateByObject(targetObj);
            logger.debug("-------------->MongoDB update start");
            return this.getMongoTemplate().updateFirst(query, update, this.getEntityClass()).getModifiedCount();
        }
        return 0;
    }

    @Override
    public long update(Object id, Map<String, Object> fieldsMap) {
        if (id == null || MapUtils.isEmpty(fieldsMap)) return 0;
        Query query = new Query(Criteria.where("_id").is(id));
        Update update = new Update();
        for (Map.Entry<String, Object> fieldValue : fieldsMap.entrySet()) {
            update.set(fieldValue.getKey(), fieldValue.getValue());
        }
        return this.getMongoTemplate().updateFirst(query, update, this.getEntityClass()).getModifiedCount();
    }

    @Override
    public long update(Object id, String field, Object value) {
        if (id == null) return 0;
        Query query = new Query(Criteria.where("_id").is(id));
        Update update = Update.update(field, value);
        return this.getMongoTemplate().updateFirst(query, update, this.getEntityClass()).getModifiedCount();
    }

    public long updateFirst(T srcObj, T targetObj) {
        Query query = getQueryByObject(srcObj);
        Update update = getUpdateByObject(targetObj);
        logger.debug("-------------->MongoDB updateFirst start");
        return this.getMongoTemplate().updateFirst(query, update, this.getEntityClass()).getModifiedCount();
    }

    public long updateMulti(T srcObj, T targetObj) {
        Query query = getQueryByObject(srcObj);
        Update update = getUpdateByObject(targetObj);
        logger.debug("-------------->MongoDB updateFirst start");
        return this.getMongoTemplate().updateMulti(query, update, this.getEntityClass()).getModifiedCount();
    }

    public long updateInsert(T srcObj, T targetObj) {
        Query query = getQueryByObject(srcObj);
        Update update = getUpdateByObject(targetObj);
        logger.debug("-------------->MongoDB updateInsert start");
        return this.getMongoTemplate().upsert(query, update, this.getEntityClass()).getModifiedCount();
    }

    /**
     * 将查询条件对象转换为query
     *
     * @param object
     * @return
     * @author Jason
     */
    private Query getQueryByObject(T object) {
        Query query = new Query();
        Field[] fileds = getFieldName(object);
        Criteria criteria = new Criteria();
        for (int i = 0; i < fileds.length; i++) {
            Field field = fileds[i];
            Object filedValue = getFieldValue(field, object);
            if (filedValue != null) {
                if (null == field.getAnnotation(Transient.class)) {
                    criteria.and(field.getName()).is(filedValue);
                }
            }
        }
        query.addCriteria(criteria);
        return query;
    }

    /**
     * 将查询条件对象转换为update
     *
     * @param object
     * @return
     * @author Jason
     */
    private Update getUpdateByObject(T object) {
        Update update = new Update();
        Field[] fileds = getFieldName(object);
        for (int i = 0; i < fileds.length; i++) {
            Field field = fileds[i];
            Object filedValue = getFieldValue(field, object);
            if (filedValue != null) {
                if (null == field.getAnnotation(Transient.class)) {
                    update.set(field.getName(), filedValue);
                }
            }
        }
        return update;
    }

    /***
     * 获取对象属性返回字符串数组
     * @param o
     * @return
     */
    private static Field[] getFieldName(Object o) {
        return o.getClass().getDeclaredFields();
    }

    /***
     * 根据属性获取对象属性值
     * @param field
     * @param o
     * @return
     */
    private static Object getFieldValue(Field field, Object o) {
        try {
            field.setAccessible(true);
            return field.get(o);
        } catch (Exception var6) {
            return null;
        }
    }
}
