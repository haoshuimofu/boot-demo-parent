package com.ddmc.sso.client.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class AdminSsoClientConfig {

    @Bean(name = "privilegeConfig")
    @ConfigurationProperties(prefix = "sso.admin.privilege")
    public PrivilegeConfig privilegeConfig() {
        System.out.println("-------------------- privilege init ---------------------");
        return new PrivilegeConfig();
    }

    @Bean(name = "loginSettingConfig")
    @ConfigurationProperties(prefix = "sso.admin.login.setting")
    public LoginSettingConfig loginSettingConfig() {
        System.out.println("-------------------- loginSettingConfig init ---------------------");
        return new LoginSettingConfig();
    }
}
