package com.ddmc.sso.client.vo.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import javax.ws.rs.QueryParam;
import java.io.Serializable;

public class UserInfoRequestVo implements Serializable {
    @QueryParam("app_id")
    private String appId;

    @QueryParam("sign")
    private String sign ;

    @QueryParam("token")
    private String token ;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
