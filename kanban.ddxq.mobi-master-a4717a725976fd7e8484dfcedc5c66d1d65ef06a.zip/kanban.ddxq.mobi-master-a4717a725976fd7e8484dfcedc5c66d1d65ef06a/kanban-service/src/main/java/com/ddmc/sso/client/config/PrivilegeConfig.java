package com.ddmc.sso.client.config;

/**
 * 在admin sso系统注册的参数
 */
public class PrivilegeConfig {
    private String appid ;
    private String appkey;
    private String admin ;

    public String getAppid() {
        return appid;
    }

    public void setAppid(String appid) {
        this.appid = appid;
    }

    public String getAppkey() {
        return appkey;
    }

    public void setAppkey(String appkey) {
        this.appkey = appkey;
    }

    public String getAdmin() {
        return admin;
    }

    public void setAdmin(String admin) {
        this.admin = admin;
    }
}
