package com.ddmc.kanban.dao.kanban;

import com.ddmc.kanban.dao.base.BaseMysqlDao;
import com.ddmc.kanban.model.yestodayquality.YestodayQualityControlBatch;
import com.ddmc.kanban.model.yestodayquality.YestodayQualityControlDetail;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface YestodayQualityControlBatchDao extends BaseMysqlDao<YestodayQualityControlBatch, Long> {


    /**
     * @param startIndex
     * @param pageSize
     * @return
     */
    List<YestodayQualityControlBatch> getPageList(@Param("startIndex") Long startIndex, @Param("pageSize") Integer pageSize);

    /**
     * @return
     */
    int getPageListCount();

    /**
     * @param qualityId
     * @return
     */
    YestodayQualityControlDetail queryDetailByQualityId(@Param("qualityId") Long qualityId);

    /**
     * @param startTime
     * @param endTime
     * @return
     */
    List<YestodayQualityControlBatch> queryYestodayData(@Param("cityId") String cityId,@Param("startTime") Date startTime, @Param("endTime") Date endTime);

    /**
     * 查询昨日未质检数据
	 * @param cityId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<YestodayQualityControlBatch> queryYestodayUnQualityData(@Param("cityId") String cityId,@Param("startTime") Date startTime, @Param("endTime") Date endTime);
    

	/**
	 * 查询昨日质检通过数
	 * @param cityId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<YestodayQualityControlBatch> queryYestodayQualifiedData(@Param("cityId") String cityId,@Param("startTime") Date startTime, @Param("endTime") Date endTime);
	
	/**
	 * 查询昨日质检不通过数
	 * @param cityId
	 * @param startTime
	 * @param endTime
	 * @return
	 */
	List<YestodayQualityControlBatch> queryYestodayUnQualifiedData(@Param("cityId") String cityId,@Param("startTime") Date startTime, @Param("endTime") Date endTime);

	
    /**
     * @return
     */
    String queryCurrentBatchId();

    /**
     * @param list
     */
    int saveList(List<YestodayQualityControlBatch> list);

    /**
     * @param batchId
     */
    void updateOldDataHidden(@Param("originalBatchId") String originalBatchId);

	
	


}
