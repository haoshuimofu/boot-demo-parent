package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.view.ResponseBaseVo;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 *
 */
@RestController
@RequestMapping(value = "api/gov", produces = { MediaType.APPLICATION_JSON_VALUE })
public class IndexController {

    @RequestMapping("/index")
    public ResponseBaseVo index(HttpServletRequest request, HttpServletResponse response) {
        Map map = new HashMap<String,String>();
        map.put("username", request.getParameter("username"));
        return ResponseBaseVo.ok(map);
    }
}