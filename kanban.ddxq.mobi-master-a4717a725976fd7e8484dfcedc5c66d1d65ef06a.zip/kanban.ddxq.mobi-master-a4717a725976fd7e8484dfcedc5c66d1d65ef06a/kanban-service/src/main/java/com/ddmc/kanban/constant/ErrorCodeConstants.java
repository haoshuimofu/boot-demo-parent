package com.ddmc.kanban.constant;

/**
 * 错误码常量类--前三位为服务名，全公司统一管理，后六位为应用自己定义编码
 */
public enum ErrorCodeConstants {

    ERROR_CODE_000(Constants.ERROR_CODE_PRE_OF_PAY + "100000", "请求缺少参数"),

    ERROR_CODE_101(Constants.ERROR_CODE_PRE_OF_PAY + "100101", "登录失败！"),

    ERROR_CODE_401(Constants.ERROR_CODE_PRE_OF_PAY + "100401", "appId不能为空"),
    ERROR_CODE_402(Constants.ERROR_CODE_PRE_OF_PAY + "100402", "sign不能为空"),
    ERROR_CODE_403(Constants.ERROR_CODE_PRE_OF_PAY + "100403", "productName不能为空"),
    ERROR_CODE_404(Constants.ERROR_CODE_PRE_OF_PAY + "100404", "batchNum不能为空"),


    ERROR_CODE_901(Constants.ERROR_CODE_PRE_OF_PAY + "100901", "叮咚去邻居家串门了，马上回来～");

    private String errorCode;
    private String errorMsg;

    private ErrorCodeConstants(String errorCode, String errorMsg) {
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public String getErrorCode() {
        return errorCode;
    }

    public String getErrorMsg() {
        return errorMsg;
    }
}
