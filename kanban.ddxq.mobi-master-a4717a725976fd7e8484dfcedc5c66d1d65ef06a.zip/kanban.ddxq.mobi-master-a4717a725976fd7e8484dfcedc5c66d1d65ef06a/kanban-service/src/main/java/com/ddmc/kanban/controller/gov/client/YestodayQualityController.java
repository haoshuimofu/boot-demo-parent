package com.ddmc.kanban.controller.gov.client;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.ddmc.core.model.Pagination;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.constant.ErrorCodeConstants;
import com.ddmc.kanban.model.yestodayquality.YestodayQualitySummary;
import com.ddmc.kanban.response.YestodayQualityControlDetailVo;
import com.ddmc.kanban.response.YestodayQualityControlVo;
import com.ddmc.kanban.response.YestodayQualitySummaryVo;
import com.ddmc.kanban.service.YestodayQualityService;

/**
 * 
* <p>Description:看板-昨日入库质检api接口 </p>    
* @author chenkai  
* @date 2019年3月20日
 */
@RestController
@RequestMapping(value = "api/gov/yestodayQuality", consumes = { MediaType.APPLICATION_JSON_UTF8_VALUE,
		MediaType.APPLICATION_JSON_VALUE }, produces = { MediaType.APPLICATION_JSON_VALUE })
public class YestodayQualityController {

	private final YestodayQualityService yestodayQualityService;

	public YestodayQualityController(YestodayQualityService yestodayQualityService) {
		this.yestodayQualityService = yestodayQualityService;
	}

	@GetMapping("summary")
	public ResponseBaseVo<YestodayQualitySummaryVo> getSummary() {
		YestodayQualitySummary summary = yestodayQualityService.getFirstSummary();
		YestodayQualitySummaryVo vo = new YestodayQualitySummaryVo();
		vo.setTotalCount(summary.getTotalCount());
		vo.setUnQualifiedCount(summary.getUnQualifiedCount());
		vo.setUnQualityCount(summary.getUnQualityCount());
		return ResponseBaseVo.ok(vo);
	}

	@GetMapping("list")
	public ResponseBaseVo<Pagination<YestodayQualityControlVo>> getList(@RequestParam("page") Integer page, @RequestParam("pageSize") Integer pageSize) {
		Pagination<YestodayQualityControlVo> pageData = null;
		try {
			pageData = yestodayQualityService.getPageList(page,pageSize);
			return ResponseBaseVo.ok(pageData);
		} catch (Exception e) {
			return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_901.getErrorCode(), ErrorCodeConstants.ERROR_CODE_901.getErrorMsg(),pageData);
		}
	}
	
	@GetMapping("detail")
	public ResponseBaseVo<YestodayQualityControlDetailVo> getDetail(@RequestParam("qualityId") Long qualityId) {
		YestodayQualityControlDetailVo vo = null;
		try {
			vo = yestodayQualityService.getDetail(qualityId);
			return ResponseBaseVo.ok(vo);
		} catch (Exception e) {
			return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_901.getErrorCode(), ErrorCodeConstants.ERROR_CODE_901.getErrorMsg(),vo);
		}
	}
	
	/**
	 * 每天上午8点执行job，处理昨天的数据
	 * @param qualityId
	 * @return
	 */
	@GetMapping("batchHandle")
	public ResponseBaseVo<Integer> batchHandle() {
		try {
			int totalCount = yestodayQualityService.batchHandler();
			return ResponseBaseVo.ok(totalCount);
		} catch (Exception e) {
			return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_901.getErrorCode(), ErrorCodeConstants.ERROR_CODE_901.getErrorMsg(),null);
		}
	}
	
}
