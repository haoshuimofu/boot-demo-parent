package com.ddmc.sso.client.util;

import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * 为spring security提供MD5 PasswordEncoder
 * @summary
 */
public class Md5PasswordEncoder implements PasswordEncoder {

    private String salt;

    public String getSalt() {
        return salt;
    }

    public void setSalt(String salt) {
        if(null == salt) {
            this.salt = "";
        }else {
            this.salt = salt.trim();
        }
    }


    @Override
    public String encode(CharSequence rawPassword) {
            String pass = salt + rawPassword;
            return DigestUtils.md5Hex(pass);
    }

    @Override
    public boolean matches(CharSequence rawPassword, String encodedPassword) {
        String pass = salt + rawPassword;
        if(DigestUtils.md5Hex(pass).equals(encodedPassword)){
            return true;
        }
        return false;
    }
}
