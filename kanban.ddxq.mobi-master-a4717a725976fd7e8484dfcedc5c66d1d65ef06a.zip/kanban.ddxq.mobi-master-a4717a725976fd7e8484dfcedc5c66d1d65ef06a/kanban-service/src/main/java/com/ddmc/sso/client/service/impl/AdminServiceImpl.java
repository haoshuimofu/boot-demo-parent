package com.ddmc.sso.client.service.impl;

import com.ddmc.redis.ICacheManager;
import com.ddmc.sso.client.AdminSsoClient;
import com.ddmc.sso.client.config.LoginSettingConfig;
import com.ddmc.sso.client.config.PrivilegeConfig;
import com.ddmc.sso.client.service.AdminService;
import com.ddmc.sso.client.util.CookieManager;
import com.ddmc.sso.client.vo.request.AuthRequestVo;
import com.ddmc.sso.client.vo.request.CheckRequestVo;
import com.ddmc.sso.client.vo.request.UserInfoRequestVo;
import com.ddmc.sso.client.vo.response.CheckReponseVo;
import com.ddmc.sso.client.vo.response.UserInfoResponseVo;
import com.ddmc.utils.net.QueryStringUtil;
import com.ddmc.utils.uuid.UUIDTool;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.TreeMap;

@Service
public class AdminServiceImpl implements AdminService {
    protected Logger logger = LoggerFactory.getLogger(AdminServiceImpl.class);

    private static final String PARAM_PRIVATE_KEY = "private_key";
    private static final String PARAM_APP_ID = "app_id";
    private static final String PARAM_TOKEN = "token";
    private static final String PARAM_REMEMBER = "remember";
    private static final String PARAM_TIME = "time";
    /**
     * 登录态最小过期时间
     */
    private static final int COOKIE_MIN_TIMEOUT = 30 * 60;
    /**
     * 登录态最大过期时间
     */
    private static final int COOKIE_MAX_TIMEOUT = 12 * 60 * 60;

    @Autowired
    private LoginSettingConfig loginSettingConfig;

    @Autowired
    private ICacheManager cacheManager ;

    @Autowired
    private PrivilegeConfig privilegeConfig;

    @Autowired
    private AdminSsoClient adminSsoClient;


    @Override
    public UserInfoResponseVo auth(HttpServletRequest request, HttpServletResponse response, AuthRequestVo authRequestVo) {
        if(StringUtils.isBlank(authRequestVo.getToken()) || StringUtils.isBlank(authRequestVo.getSign())){
            //TODO
            logger.error("入参为空：token={}, sign={}", authRequestVo.getToken(),authRequestVo.getSign());
            return  null;
        }
        String sign = authMakeSign(authRequestVo);
        if(null == sign || ! sign.equals(authRequestVo.getSign())) {
            logger.error("签名不对，入参sign={},计算sign={}", authRequestVo.getToken(),authRequestVo.getSign());
            return  null;
        }
        UserInfoResponseVo userInfoResponseVo = this.getUserInfo(authRequestVo);
        if(null!= userInfoResponseVo){
            saveSession(request,response,authRequestVo);
        }
        return userInfoResponseVo;
    }

    @Override
    public boolean checkAccess(HttpServletRequest request, HttpServletResponse response) {
        String access = request.getServletPath();
        AuthRequestVo authRequestVo = getSession(request,response);
        if(null== authRequestVo || StringUtils.isBlank(authRequestVo.getToken())){
            return false;
        }
        String sign = authMakeSign(authRequestVo);
        if(StringUtils.isBlank(sign)){
            //TODO
            return  false;
        }
        try {
            CheckReponseVo checkReponseVo = adminSsoClient.checkAccess(privilegeConfig.getAppid(), authRequestVo.getToken(), access, sign);
            if(null == checkReponseVo || checkReponseVo.getCode()!=0){
                //TODO
                return false;
            }
        }catch (Exception e) {
            //TODO
        }
        return true;
    }

    /**
     * 生成签名
     * @param authRequestVo
     * @return
     */
    private String authMakeSign(AuthRequestVo authRequestVo){
        if(StringUtils.isBlank(authRequestVo.getToken())){
            return null;
        }
        TreeMap map = new TreeMap();
//        map.put(PARAM_APP_ID, privilegeConfig.getAppid());
        map.put(PARAM_TOKEN,authRequestVo.getToken());
        map.put(PARAM_PRIVATE_KEY, privilegeConfig.getAppkey());
        map.put(PARAM_REMEMBER,authRequestVo.getRemember());
        map.put(PARAM_TIME,authRequestVo.getTime());
        String queryStr = QueryStringUtil.buildQueryStr(map);
        return DigestUtils.md5Hex(queryStr);
    }

    /**
     * 生成签名
     * @param authRequestVo
     * @return
     */
    private UserInfoResponseVo getUserInfo(AuthRequestVo authRequestVo){
        if(null == authRequestVo || StringUtils.isBlank(authRequestVo.getToken())){
            return null;
        }
        String sign = authMakeSign(authRequestVo);
        try {
            UserInfoResponseVo userInfoResponseVo = adminSsoClient.getUserInfo(privilegeConfig.getAppid(),authRequestVo.getToken(),sign);
            return userInfoResponseVo;
        }catch (Exception e) {
            logger.error("未获取到用户信息，入参token={}、sign={}、time={}", authRequestVo.getToken(),authRequestVo.getSign(),authRequestVo.getTime());
        }
        return null;
    }

    @Override
    public void loginOut(HttpServletRequest request, HttpServletResponse response) {
        clearSession(request,response);
    }

    private int getTimeoutSetting(){
        int timeout;
        if(loginSettingConfig.getTimeout()==null || loginSettingConfig.getTimeout() <= COOKIE_MIN_TIMEOUT){
            timeout = COOKIE_MIN_TIMEOUT;
        }else if(loginSettingConfig.getTimeout()> COOKIE_MAX_TIMEOUT){
            timeout = COOKIE_MAX_TIMEOUT;
        }else {
            timeout = loginSettingConfig.getTimeout();
        }
        return timeout;
    }

    /**
     * 保存登录状态，利用cookie+redis实现
     * @param request
     * @param response
     * @param authRequestVo
     */
    private void saveSession(HttpServletRequest request, HttpServletResponse response,AuthRequestVo authRequestVo){
        String cacheKey = UUIDTool.getUUID() + "_" + (new Date()).getTime();
        int timeout = getTimeoutSetting();
        saveCookie(request, response,cacheKey,timeout);
        cacheManager.putCache(getFullCacheKey(cacheKey),authRequestVo,timeout);
    }

    /**
     * 设置cookie
     * @param request
     * @param response
     * @param cacheKey
     * @param expire
     */
    private void saveCookie(HttpServletRequest request, HttpServletResponse response, String cacheKey,int expire){
        CookieManager.setCookie(response, loginSettingConfig.getCookieName(), cacheKey, request.getServerName(), expire);
    }

    private void clearCookie(HttpServletRequest request, HttpServletResponse response) {
        String domain = request.getServerName();
        CookieManager.setCookie(response, loginSettingConfig.getCookieName(), null, request.getServerName(), 0);
    }

    /**
     * 获取登录态
     * @param request
     * @param response
     * @return
     */
    public AuthRequestVo getSession(HttpServletRequest request, HttpServletResponse response){
        String cacheKey = CookieManager.getCookieValue(request, loginSettingConfig.getCookieName());
        if(StringUtils.isBlank(cacheKey)){
            return null;
        }
        AuthRequestVo result = (AuthRequestVo) cacheManager.getCache(getFullCacheKey(cacheKey));
        //如果没有获取到服务端登录信息，删除cookie
        if(null == result){
            clearCookie(request,response );
            return null;
        }
        return result;
    }

    /**
     * 删除登录态
     * @param request
     * @param response
     */
    private void clearSession(HttpServletRequest request, HttpServletResponse response){
        String cacheKey = CookieManager.getCookieValue(request, loginSettingConfig.getCookieName());
        if(StringUtils.isBlank(cacheKey)){
            return ;
        }
        cacheManager.removeCache(getFullCacheKey(cacheKey));
        clearCookie(request,response);
    }

    /**
     * 获取完整的缓存key
     * @param cacheKey
     * @return
     */
    private String getFullCacheKey(String cacheKey){
        return loginSettingConfig.getCacheNamespace() + cacheKey;
    }

    @Override
    public String getLoginUrl() {
        if( loginSettingConfig.getLoginUrl().indexOf("?")>0 ) {
            return loginSettingConfig.getLoginUrl() + "&app_id=" + privilegeConfig.getAppid();
        }else {
            return loginSettingConfig.getLoginUrl() + "?app_id=" + privilegeConfig.getAppid();
        }
    }

    @Override
    public String getForbiddenUrl() {
        return loginSettingConfig.getForbiddenUrl();
    }

    @Override
    public String getIndexUrl() {
        return loginSettingConfig.getIndexUrl();
    }

    @Override
    public String getForceLoginUrls() {
        return loginSettingConfig.getForceLoginUrls();
    }

    @Override
    public String getUrlPatterns() {
        return loginSettingConfig.getUrlPatterns();
    }
}
