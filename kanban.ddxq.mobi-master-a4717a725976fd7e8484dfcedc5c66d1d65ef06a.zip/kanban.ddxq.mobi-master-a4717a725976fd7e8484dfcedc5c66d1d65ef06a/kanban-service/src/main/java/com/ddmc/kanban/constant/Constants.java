package com.ddmc.kanban.constant;

/**
 * 业务常量静态类
 */
public interface Constants {

    /***用户中心服务工程错误码前缀 ，见  http://git.ddxq.mobi/docs/dev_team/blob/master/backend/微服务建设/错误编码前三位-服务标识-约定.md ***/
    String ERROR_CODE_PRE_OF_PAY = "216";


    String NOT_UPLOADED = "未上传";
    String NORMAL = "正常";
    String EXPIRE = "已过期";


    /**
     * 商品无库存且过期20天移到历史表
     */
    int EXPIRED_DAY_TO_HISTORY = 20;
}
