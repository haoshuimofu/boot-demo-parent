package com.ddmc.kanban.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;

import javax.sql.DataSource;

/**
 * @author dell
 * @version 1.0.0
 * @create 2018-09-30 13:05
 */
@Configuration
@MapperScan(basePackages = {"com.ddmc.kanban.dao.kanban"}, sqlSessionTemplateRef = "kanbanSqlSessionTemplate")
public class KanbanDaoConfiguration {


    @Bean(name = "kanbanDataSource")
    //@Primary
    @ConfigurationProperties(prefix = "kanban.datasource.mysql")
    public DataSource userDataSource() {
        return new DruidDataSource();
    }

    @Bean(name = "kanbanSqlSessionFactory")
    public SqlSessionFactory kanbanSqlSessionFactory(@Qualifier("kanbanDataSource") DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        bean.setMapperLocations(new PathMatchingResourcePatternResolver().getResources("classpath*:com/ddmc/kanban/*.xml"));
        return bean.getObject();
    }

    @Bean
    public SqlSessionTemplate kanbanSqlSessionTemplate(@Qualifier("kanbanSqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
        return new SqlSessionTemplate(sqlSessionFactory);
    }

    @Bean("kanbanTransactionManager")
    // @Primary
    public DataSourceTransactionManager transactionManager(@Qualifier("kanbanDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }


}