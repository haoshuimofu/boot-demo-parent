package com.ddmc.kanban.config;

import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;

@Configuration
public class MultipleMongoProperties {
    @Bean(name = "maicaiMongoProperties")
    @Primary
    @ConfigurationProperties(prefix = "spring.data.mongodb.maicai")
    public MongoProperties maicaiMongoProperties() {
        System.out.println("-------------------- maicaiMongoProperties init ---------------------");
        return new MongoProperties();
    }
}
