package com.ddmc.kanban.controller.gov.client;

import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.personlicense.response.StationUserResponseVo;
import com.ddmc.kanban.constant.ErrorCodeConstants;
import com.ddmc.kanban.service.PersonLicenseService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary 人员证照
 */
@RestController
@RequestMapping(value = "api/gov/personlicense", consumes = {MediaType.APPLICATION_JSON_UTF8_VALUE, MediaType.APPLICATION_JSON_VALUE},
        produces = {MediaType.APPLICATION_JSON_VALUE})
public class PersonLicenseController {

    @Autowired
    private PersonLicenseService personLicenseService;

    @RequestMapping(value = "/getStationList", method = RequestMethod.GET)
    public ResponseBaseVo<List<String>> getStationList(@RequestParam(value = "appId", required = false) String appId, @RequestParam(value = "sign", required = false) String sign, @RequestParam(value = "area", required = false) String area) {
        ResponseBaseVo result = checkParams(appId, sign);
        if (result != null) {
            return result;
        }
        return personLicenseService.getStationList(appId, sign, area);
    }

    @RequestMapping(value = "/getUser", method = RequestMethod.GET)
    public ResponseBaseVo<StationUserResponseVo> getUser(@RequestParam(value = "appId", required = false) String appId, @RequestParam(value = "sign", required = false) String sign, @RequestParam(value = "area", required = false) String area,
                                                         @RequestParam(value = "station", required = false) String station, @RequestParam(value = "page", required = false) Integer page,
                                                         @RequestParam(value = "rows", required = false) Integer rows) {
        ResponseBaseVo result = checkParams(appId, sign);
        if (result != null) {
            return result;
        }
        return personLicenseService.getUser(appId, sign, area, station, page, rows);
    }

    private ResponseBaseVo checkParams(@RequestParam("appId") String appId, @RequestParam("sign") String sign) {
        if (StringUtils.isBlank(appId)) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_401.getErrorCode(), ErrorCodeConstants.ERROR_CODE_401.getErrorMsg());
        }
        if (StringUtils.isBlank(sign)) {
            return ResponseBaseVo.fail(ErrorCodeConstants.ERROR_CODE_402.getErrorCode(), ErrorCodeConstants.ERROR_CODE_402.getErrorMsg());
        }
        return null;
    }
}
