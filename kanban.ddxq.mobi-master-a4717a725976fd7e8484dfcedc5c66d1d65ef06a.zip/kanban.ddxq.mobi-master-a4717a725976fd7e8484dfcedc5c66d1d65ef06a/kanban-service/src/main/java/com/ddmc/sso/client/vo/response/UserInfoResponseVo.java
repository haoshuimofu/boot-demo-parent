package com.ddmc.sso.client.vo.response;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public class UserInfoResponseVo implements Serializable {

    @JsonProperty("_id")
    private String id;

    private String name;

    private String email;

    @JsonProperty("is_admin")
    private Integer isAdmin;

    private Map<String,String> roles;

    @JsonProperty("ext_data")
    private Map<String,String> extData;

    private List areas;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(Integer isAdmin) {
        this.isAdmin = isAdmin;
    }

    public Map<String, String> getRoles() {
        return roles;
    }

    public void setRoles(Map<String, String> roles) {
        this.roles = roles;
    }

    public Map<String, String> getExtData() {
        return extData;
    }

    public void setExtData(Map<String, String> extData) {
        this.extData = extData;
    }

    public List getAreas() {
        return areas;
    }

    public void setAreas(List areas) {
        this.areas = areas;
    }
}
