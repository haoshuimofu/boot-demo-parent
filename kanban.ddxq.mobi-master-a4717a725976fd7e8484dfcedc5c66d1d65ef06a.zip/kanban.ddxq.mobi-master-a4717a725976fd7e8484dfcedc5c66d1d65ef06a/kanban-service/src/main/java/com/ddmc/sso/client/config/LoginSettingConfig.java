package com.ddmc.sso.client.config;

public class LoginSettingConfig {
    /**
     * 登录信息redis缓存命名空间
     */
    private String cacheNamespace;

    /**
     * 登录信息过期时长
     */
    private Integer timeout;

    /**
     * cookie名称
     */
    private String cookieName;

    /**
     * admin sso登录URL
     */
    private String loginUrl;


    private String indexUrl;

    /**
     * 无权登录提示信息URL
     */
    private String forbiddenUrl;

    /**
     * 必须登录才可以访问的URL，建议按照目录规划URL，比如/xxx/yyy/，而非/xxx/yyy/zzz.do
     */
    private String forceLoginUrls;

    /**
     * 需要经过filter的URL规则，可以过滤掉HTML、CSS、JS等文件，只针对需要过滤的进行过滤
     */
    private String urlPatterns;

    public String getCacheNamespace() {
        return cacheNamespace;
    }

    public void setCacheNamespace(String cacheNamespace) {
        this.cacheNamespace = cacheNamespace;
    }

    public Integer getTimeout() {
        return timeout;
    }

    public void setTimeout(Integer timeout) {
        this.timeout = timeout;
    }

    public String getCookieName() {
        return cookieName;
    }

    public void setCookieName(String cookieName) {
        this.cookieName = cookieName;
    }

    public String getLoginUrl() {
        return loginUrl;
    }

    public void setLoginUrl(String loginUrl) {
        this.loginUrl = loginUrl;
    }

    public String getForbiddenUrl() {
        return forbiddenUrl;
    }

    public void setForbiddenUrl(String forbiddenUrl) {
        this.forbiddenUrl = forbiddenUrl;
    }

    public String getIndexUrl() {
        return indexUrl;
    }

    public void setIndexUrl(String indexUrl) {
        this.indexUrl = indexUrl;
    }

    public String getForceLoginUrls() {
        return forceLoginUrls;
    }

    public void setForceLoginUrls(String forceLoginUrls) {
        this.forceLoginUrls = forceLoginUrls;
    }

    public String getUrlPatterns() {
        return urlPatterns;
    }

    public void setUrlPatterns(String urlPatterns) {
        this.urlPatterns = urlPatterns;
    }
}
