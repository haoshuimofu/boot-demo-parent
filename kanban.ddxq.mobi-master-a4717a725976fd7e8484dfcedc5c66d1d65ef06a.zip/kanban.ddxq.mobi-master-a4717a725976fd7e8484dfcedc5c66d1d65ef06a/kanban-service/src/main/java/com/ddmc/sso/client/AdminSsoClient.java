package com.ddmc.sso.client;

/**
 * @author hudajin
 * @data 2019/3/18
 * @summary
 */

import com.ddmc.sso.client.feign.AdminReadConfiguration;
import com.ddmc.sso.client.vo.request.CheckRequestVo;
import com.ddmc.sso.client.vo.request.UserInfoRequestVo;
import com.ddmc.sso.client.vo.response.CheckReponseVo;
import com.ddmc.sso.client.vo.response.UserInfoResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Component
@FeignClient(name = "adminSso", url = "${sso.admin.base.path}",  configuration = AdminReadConfiguration.class)
public interface AdminSsoClient {

    @RequestMapping(value = "/api/getUserInfo",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    //UserInfoResponseVo getUserInfo(UserInfoRequestVo userInfoRequestVo) throws Exception;
    UserInfoResponseVo getUserInfo(@RequestParam("app_id") String appId, @RequestParam("token") String token, @RequestParam("sign") String sign) throws Exception;

    @RequestMapping(value = "/api/check",method = RequestMethod.GET,produces = MediaType.APPLICATION_JSON_VALUE)
    //CheckReponseVo checkAccess(@RequestBody CheckRequestVo checkRequestVo) throws Exception;
    CheckReponseVo checkAccess(@RequestParam("app_id") String appId, @RequestParam("token") String token, @RequestParam("sign") String sign , @RequestParam("auth_item") String authItem) throws Exception;
}
