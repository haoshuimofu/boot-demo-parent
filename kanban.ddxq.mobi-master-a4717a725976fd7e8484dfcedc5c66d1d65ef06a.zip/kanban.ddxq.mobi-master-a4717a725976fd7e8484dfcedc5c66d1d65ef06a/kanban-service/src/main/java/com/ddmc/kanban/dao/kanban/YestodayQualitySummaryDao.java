package com.ddmc.kanban.dao.kanban;

import com.ddmc.kanban.dao.base.BaseMysqlDao;
import com.ddmc.kanban.model.yestodayquality.YestodayQualitySummary;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;

@Repository
public interface YestodayQualitySummaryDao extends BaseMysqlDao<YestodayQualitySummary, Long> {

    YestodayQualitySummary queryNewest();

    /**
     * @param summary
     */
    int save(YestodayQualitySummary summary);

}
