package com.ddmc.sso.client.filter;

import com.ddmc.sso.client.service.AdminService;
import com.ddmc.sso.client.util.CtxSessionBag;
import com.ddmc.sso.client.vo.request.AuthRequestVo;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 *
 */
public class AdminLoginFilter implements Filter {

    protected Logger logger = LoggerFactory.getLogger(AdminLoginFilter.class);

    /** 强制登陆参数的分隔符 */
    private final static String PARAM_FORCE_LOGIN_SPLIT = ",";
    /** 必须登录认证的URL */
    private String[] forceLoginArr = null;

    private AdminService adminService;

    public AdminLoginFilter(AdminService adminService){
        this.adminService =adminService;
        if(! StringUtils.isBlank(adminService.getForceLoginUrls())) {
            this.forceLoginArr = adminService.getForceLoginUrls().split(PARAM_FORCE_LOGIN_SPLIT);
            for(int i =0 ;i <this.forceLoginArr.length;i++){
                this.forceLoginArr[i]= this.forceLoginArr[i].trim();
            }
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse rsp, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) rsp;

        CtxSessionBag.clear();  //备注，在开始的时候就需要清理threadLocal，否则可能出现


        // 如果用户已经登录,则直接返回用户的认证信息
        AuthRequestVo authRequestVo = adminService.getSession(request, response);
        if ( null !=authRequestVo || ! StringUtils.isBlank(authRequestVo.getToken())) {
            CtxSessionBag.setCasSessionBag(authRequestVo);
            if(adminService.checkAccess(request, response)){
                /*forbidden(response);
                return;*/
                request.getRequestDispatcher(adminService.getForbiddenUrl()).forward(request, response);
            }else{
                chain.doFilter(request, response);
            }
            return;
        } else {
            if (!isForceLogin(request)) { // 不需要登录验证
                chain.doFilter(request, response);
                return;
            } else { // 需要登陆，但未登陆,则跳转到登陆页面
                response.sendRedirect(adminService.getLoginUrl());
                return;
            }
        }
    }

    @Override
    public void destroy() {

    }

    protected boolean isForceLogin(HttpServletRequest request) {
        boolean isForceLogin = false;
        String path = request.getServletPath();
        if(forceLoginArr != null && forceLoginArr.length != 0) {
            for (String forceLogin : forceLoginArr) {
                if (path.startsWith(forceLogin)) {
                    isForceLogin = true;
                    break;
                }
            }
        }
        return isForceLogin;
    }

/*    protected void forbidden(HttpServletResponse response){
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=utf-8");
        PrintWriter out = null ;
        try{
            JSONObject res = new JSONObject();
            res.put("success","false");
            res.put("msg","xxxx");
            out = response.getWriter();
            out.append(res.toString());
            out.flush();
        }catch (Exception e){
            e.printStackTrace();
            try {
                response.sendError(500);
            }catch (Exception ioe){
            }
        }
    }*/

}
