package com.ddmc.kanban.constant;

/**
 * 队列queue常量
 *
 * @Author wude
 * @Create 2019-03-06 14:25
 */
public class QueueConstants {
    
}