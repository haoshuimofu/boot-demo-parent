package com.ddmc.sso.client.vo.request;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class CheckRequestVo implements Serializable {

    @JsonProperty("app_id")
    private String appId;

    private String sign ;

    private String token ;

    @JsonProperty("auth_item")
    private String authItem ;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getAuthItem() {
        return authItem;
    }

    public void setAuthItem(String authItem) {
        this.authItem = authItem;
    }
}
