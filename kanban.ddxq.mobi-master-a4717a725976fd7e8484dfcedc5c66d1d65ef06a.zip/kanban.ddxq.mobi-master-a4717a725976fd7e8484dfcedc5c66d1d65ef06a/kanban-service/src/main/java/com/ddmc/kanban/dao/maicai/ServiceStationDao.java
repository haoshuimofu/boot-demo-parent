package com.ddmc.kanban.dao.maicai;

import com.ddmc.kanban.dao.base.BaseDao;
import com.ddmc.kanban.model.maicai.ServiceStation;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/21
 * @summary
 */
public interface ServiceStationDao extends BaseDao<ServiceStation> {

    List<ServiceStation> queryByArea(String area);
}
