package com.ddmc.kanban.model.yestodayquality;

import java.util.Date;

/**
 * 
* <p>Description: </p>    
* @author chenkai  
* @date 2019年3月19日
 */
public class YestodayQualitySummary {
	
	private Long id;
	
	private String batchId;
	
	private Date summaryDate;
	
	private Integer totalCount;
	
	private Integer unQualityCount;
	
	private Integer unQualifiedCount;
	
	private Date createTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Date getSummaryDate() {
		return summaryDate;
	}

	public void setSummaryDate(Date summaryDate) {
		this.summaryDate = summaryDate;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getUnQualityCount() {
		return unQualityCount;
	}

	public void setUnQualityCount(Integer unQualityCount) {
		this.unQualityCount = unQualityCount;
	}

	public Integer getUnQualifiedCount() {
		return unQualifiedCount;
	}

	public void setUnQualifiedCount(Integer unQualifiedCount) {
		this.unQualifiedCount = unQualifiedCount;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getBatchId() {
		return batchId;
	}

	public void setBatchId(String batchId) {
		this.batchId = batchId;
	}


}
