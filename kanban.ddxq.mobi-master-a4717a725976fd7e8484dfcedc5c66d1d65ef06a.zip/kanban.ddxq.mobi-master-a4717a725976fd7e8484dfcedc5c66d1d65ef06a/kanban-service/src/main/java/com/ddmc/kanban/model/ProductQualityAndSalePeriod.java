package com.ddmc.kanban.model;

/**
 * 商品保质期和可售期Bean，用于mybatis查询返回，节省内存空间
 *
 * @Author wude
 * @Create 2019-03-19 15:37
 */
public class ProductQualityAndSalePeriod {

    private Integer productId;
    private Integer qualityPeriod;
    private Integer salePeriod;

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public Integer getQualityPeriod() {
        return qualityPeriod;
    }

    public void setQualityPeriod(Integer qualityPeriod) {
        this.qualityPeriod = qualityPeriod;
    }

    public Integer getSalePeriod() {
        return salePeriod;
    }

    public void setSalePeriod(Integer salePeriod) {
        this.salePeriod = salePeriod;
    }
}