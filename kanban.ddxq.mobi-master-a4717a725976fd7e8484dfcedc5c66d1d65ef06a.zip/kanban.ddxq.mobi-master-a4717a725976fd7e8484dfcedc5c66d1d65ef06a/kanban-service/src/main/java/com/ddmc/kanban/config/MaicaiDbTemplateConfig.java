package com.ddmc.kanban.config;

import com.mongodb.MongoClientURI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.mongo.MongoProperties;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultMongoTypeMapper;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

@Configuration
@EnableMongoRepositories(basePackages = "com.ddmc.kanban.model.maicai", mongoTemplateRef = "maicaiMongoTemplate")
public class MaicaiDbTemplateConfig {
    @Autowired
    @Qualifier("maicaiMongoProperties")
    private MongoProperties maicaiMongoProperties;

    @Autowired
    private ApplicationContext appContext;

    @Primary
    @Bean(name = "maicaiMongoTemplate")
    public MongoTemplate maicaiMongoTemplate() throws Exception {
        MongoDbFactory factory = maicaiMongoFactory(this.maicaiMongoProperties);

        /******begin: Don't save _class to mongo *********/
        MongoMappingContext mongoMappingContext = new MongoMappingContext();
        mongoMappingContext.setApplicationContext(appContext);
        MappingMongoConverter converter = new MappingMongoConverter(new DefaultDbRefResolver(factory), mongoMappingContext);
        converter.setTypeMapper(new DefaultMongoTypeMapper(null));
        /******end: Don't save _class to mongo *********/

        return new MongoTemplate(factory, converter);
    }

    @Primary
    @Bean(name = "maicaiMongoFactory")
    public MongoDbFactory maicaiMongoFactory(MongoProperties mongoProperties) throws Exception {
        MongoClientURI clientURI = new MongoClientURI(mongoProperties.getUri());
        return new SimpleMongoDbFactory(clientURI);
    }
}
