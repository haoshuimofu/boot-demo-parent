package com.ddmc.kanban.config;


import com.ddmc.kanban.dao.kanban.GovUserDao;
import com.ddmc.kanban.login.gov.model.SecurityUser;
import com.ddmc.kanban.model.login.gov.GovUser;
import com.ddmc.sso.client.util.Md5PasswordEncoder;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.ForwardAuthenticationFailureHandler;
import org.springframework.security.web.authentication.ForwardAuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.ForwardLogoutSuccessHandler;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.CorsUtils;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;


/**
 *
 */

@Configuration
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    /**
     * 登录url
     */
    private static String loginPage = "/api/gov/login";
    /**
     * 登出url
     */
    private static String logoutUrl = "/api/gov/logout";
    /**
     * 登录成功forward url
     */
    private static String loginSuccessForward = "/api/gov/index";
    /**
     * 登录失败forward url
     */
    private static String loginFailureForward = "/api/gov/loginfailure";
    /**
     * 登出成功forward url
     */
    private static String logoutSuccessForward = "/api/gov/logoutSuccess";

    private static String[] permitUrls = {"/static/**","/manage/**","/api/admin/**"};

    @Value("${gov.cors.allowed.origin}")
    private String allowedOrigin;

    @Value("${gov.user.password.salt}")
    private String userPasswordSalt;

    private static final Logger logger = LoggerFactory.getLogger(WebSecurityConfig.class);

    @Override
    protected void configure(HttpSecurity http) throws Exception { //配置策略
        http.cors().configurationSource(corsConfigurationSource()).and().csrf().disable();
        http.authorizeRequests().requestMatchers(CorsUtils::isPreFlightRequest).permitAll().
                antMatchers(permitUrls).permitAll().anyRequest().authenticated().
                and().formLogin().loginPage(loginPage).permitAll().successHandler(loginSuccessHandler())
                .failureHandler(loginFailureHandler()).
                and().logout().logoutUrl(logoutUrl).permitAll().invalidateHttpSession(true).
                deleteCookies("JSESSIONID").logoutSuccessHandler(logoutSuccessHandler());
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.userDetailsService(userDetailsService()).passwordEncoder(passwordEncoder());
        auth.eraseCredentials(false);
    }

    /**
     * 密码加密工具BEAN
     * @return
     */
    @Bean
    public PasswordEncoder passwordEncoder() { //密码加密
        Md5PasswordEncoder result = new Md5PasswordEncoder();
        result.setSalt(userPasswordSalt);
        return result;
    }

    /**
     * 跨域设置
     * @return
     */

    @Bean
    CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        if(StringUtils.isBlank(allowedOrigin)){
            throw new RuntimeException("系统初始化错误！跨域设置为空！");
        }else {
            allowedOrigin = allowedOrigin.trim();
            configuration.setAllowedOrigins(Arrays.asList(allowedOrigin.split(",")));
        }
        configuration.addAllowedHeader("*");
        configuration.addAllowedMethod(HttpMethod.POST);
        configuration.addAllowedMethod(HttpMethod.GET);
        configuration.addAllowedMethod(HttpMethod.OPTIONS);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
/*    @Bean
    public CorsFilter corsFilter() {
        final UrlBasedCorsConfigurationSource urlBasedCorsConfigurationSource = new      UrlBasedCorsConfigurationSource();
        final CorsConfiguration corsConfiguration = new CorsConfiguration();
        corsConfiguration.setAllowCredentials(true);
        corsConfiguration.addAllowedOrigin(allowedOrigin);
        corsConfiguration.addAllowedHeader("*");
        corsConfiguration.addAllowedMethod("*");
        urlBasedCorsConfigurationSource.registerCorsConfiguration("/**", corsConfiguration);
        return new CorsFilter(urlBasedCorsConfigurationSource);
    }*/

    /**
     * 登出成功处理
     * @return
     */
    @Bean
    public ForwardLogoutSuccessHandler logoutSuccessHandler() {
        return new ForwardLogoutSuccessHandler(logoutSuccessForward);
    }

    /**
     * 登入成功处理
     * @return
     */
    @Bean
    public ForwardAuthenticationSuccessHandler loginSuccessHandler() {
        return new ForwardAuthenticationSuccessHandler(loginSuccessForward);
    }

    /**
     * 登录失败处理
     * @return
     */
    @Bean
    public ForwardAuthenticationFailureHandler loginFailureHandler(){
        return new ForwardAuthenticationFailureHandler(loginFailureForward);
    }

    @Bean
    public UserDetailsService userDetailsService() {    //用户登录实现
        return new UserDetailsService() {
            @Autowired
            private GovUserDao govUserDao;

            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                GovUser user = govUserDao.findByUsername(username);
                if (user == null) throw new UsernameNotFoundException("Username " + username + " not found");
                return new SecurityUser(user);
            }
        };
    }

}

