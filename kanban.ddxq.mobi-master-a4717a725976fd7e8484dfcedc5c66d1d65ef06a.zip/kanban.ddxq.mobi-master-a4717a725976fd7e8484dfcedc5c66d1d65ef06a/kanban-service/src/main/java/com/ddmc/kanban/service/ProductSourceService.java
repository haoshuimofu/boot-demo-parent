package com.ddmc.kanban.service;

import com.ddmc.core.model.Pagination;
import com.ddmc.core.view.ResponseBaseVo;
import com.ddmc.kanban.client.productsource.response.ProductSourceResponseVo;

/**
 * @author wangbo
 * @data 2019/3/20
 * @summary
 */
public interface ProductSourceService {

    /**
     * 根据产品名称模糊前缀匹配返回25条一页的数据
     *
     * @param productName 产品名称
     * @param page        当前页数       默认1
     * @param pageSize    每页显示多少条 默认25条
     * @return
     */
    ResponseBaseVo<Pagination> selectProductName(String productName, Integer page, Integer pageSize);

    /**
     * 商品溯源查询
     *
     * @param productName 商品名称
     * @param batchNum    批次号
     * @return
     */
    ResponseBaseVo<ProductSourceResponseVo> getSource(String productName, String batchNum);
}
