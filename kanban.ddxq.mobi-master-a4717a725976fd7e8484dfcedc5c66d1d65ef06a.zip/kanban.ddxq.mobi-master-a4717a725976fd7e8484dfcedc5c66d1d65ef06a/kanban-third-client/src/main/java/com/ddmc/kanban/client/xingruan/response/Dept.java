package com.ddmc.kanban.client.xingruan.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
public class Dept {

    @JsonProperty("CompanyID")
    private Integer companyID;
    @JsonProperty("ID")
    private Integer id;
    @JsonProperty("Name")
    private String name;

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
