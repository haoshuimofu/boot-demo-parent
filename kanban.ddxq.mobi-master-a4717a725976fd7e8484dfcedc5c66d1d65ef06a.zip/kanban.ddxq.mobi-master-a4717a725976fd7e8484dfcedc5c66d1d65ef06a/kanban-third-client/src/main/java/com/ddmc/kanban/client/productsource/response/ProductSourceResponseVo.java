package com.ddmc.kanban.client.productsource.response;

import java.io.Serializable;
import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary
 */
public class ProductSourceResponseVo implements Serializable {

    /**
     * 商品信息对象
     */
    private Product product;
    /**
     * 商品追溯信息
     */
    private List<Source> source;
    /**
     * 检测报告
     */
    private Report report;
    /**
     * 供应商信息对象
     */
    private Supplier supplier;

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public List<Source> getSource() {
        return source;
    }

    public void setSource(List<Source> source) {
        this.source = source;
    }

    public Report getReport() {
        return report;
    }

    public void setReport(Report report) {
        this.report = report;
    }

    public Supplier getSupplier() {
        return supplier;
    }

    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }
}
