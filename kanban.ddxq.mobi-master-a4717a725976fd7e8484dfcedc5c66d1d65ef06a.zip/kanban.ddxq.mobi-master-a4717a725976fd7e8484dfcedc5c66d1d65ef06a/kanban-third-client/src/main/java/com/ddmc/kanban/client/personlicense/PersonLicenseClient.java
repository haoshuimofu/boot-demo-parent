package com.ddmc.kanban.client.personlicense;

import com.ddmc.kanban.client.personlicense.config.feign.PersonLicenseReadConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
@Component
@FeignClient(name = "personlicense", url = "https://hr.api.100.me/public-api",
        configuration = PersonLicenseReadConfiguration.class)
public interface PersonLicenseClient {

    /**
     * 调用php服务端获取服务站列表接口
     *
     * @param appId 业务id  required
     * @param sign  签名    required
     * @param area  区域
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/get-station-list", method = RequestMethod.GET)
    String getStationList(@RequestParam("app_id") String appId, @RequestParam("sign") String sign, @RequestParam(value = "area", required = false) String area) throws Exception;

    /**
     * 调用php服务端获取服务站人员接口
     *
     * @param appId   业务id  required
     * @param sign    签名    required
     * @param area    区域
     * @param station 前置仓名称
     * @param page    页数     default 1
     * @param rows    每页行数 default 20
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/get-user", method = RequestMethod.GET)
    String getUser(@RequestParam("app_id") String appId, @RequestParam("sign") String sign, @RequestParam(value = "area", required = false) String area,
                   @RequestParam(value = "station", required = false) String station, @RequestParam(value = "page", required = false) Integer page,
                   @RequestParam(value = "rows", required = false) Integer rows) throws Exception;
}
