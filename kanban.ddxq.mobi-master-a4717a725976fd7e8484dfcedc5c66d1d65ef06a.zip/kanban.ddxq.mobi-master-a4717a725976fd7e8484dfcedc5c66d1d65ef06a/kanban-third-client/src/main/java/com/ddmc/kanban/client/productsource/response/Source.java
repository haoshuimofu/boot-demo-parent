package com.ddmc.kanban.client.productsource.response;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary
 */
public class Source {

    /**
     * 状态
     */
    private String title;
    /**
     * 描述
     */
    private String desc;
    private Integer linkType;
    private String linkTitle;
    private String time;
    /**
     * 状态时间
     */
    private String timeTitle;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public Integer getLinkType() {
        return linkType;
    }

    public void setLinkType(Integer linkType) {
        this.linkType = linkType;
    }

    public String getLinkTitle() {
        return linkTitle;
    }

    public void setLinkTitle(String linkTitle) {
        this.linkTitle = linkTitle;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getTimeTitle() {
        return timeTitle;
    }

    public void setTimeTitle(String timeTitle) {
        this.timeTitle = timeTitle;
    }
}
