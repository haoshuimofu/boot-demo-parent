package com.ddmc.kanban.client.personlicense.response;

import java.io.Serializable;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
public class User implements Serializable {

    /**
     * 姓名
     */
    private String name;

    /**
     * 健康证图片地址
     */
    private String healthImg;

    /**
     * 健康证开始时间
     */
    private String healthStart;

    /**
     * 健康证到期时间
     */
    private String healthEnd;

    /**
     * 通过健康证到期时间计算得到 有 正常  过期  未上传
     */
    private String status;

    /**
     * 前置仓名称
     */
    private String station;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getHealthImg() {
        return healthImg;
    }

    public void setHealthImg(String healthImg) {
        this.healthImg = healthImg;
    }

    public String getHealthStart() {
        return healthStart;
    }

    public void setHealthStart(String healthStart) {
        this.healthStart = healthStart;
    }

    public String getHealthEnd() {
        return healthEnd;
    }

    public void setHealthEnd(String healthEnd) {
        this.healthEnd = healthEnd;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStation() {
        return station;
    }

    public void setStation(String station) {
        this.station = station;
    }
}
