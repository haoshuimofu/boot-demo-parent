package com.ddmc.kanban.client.productsource.response;

import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary
 */
public class Supplier {

    private String vendorName;
    private List<String> introImages;
    private List<String> qualificationImages;
    private List<String> qualityImages;
    private String introduce;

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public List<String> getIntroImages() {
        return introImages;
    }

    public void setIntroImages(List<String> introImages) {
        this.introImages = introImages;
    }

    public List<String> getQualificationImages() {
        return qualificationImages;
    }

    public void setQualificationImages(List<String> qualificationImages) {
        this.qualificationImages = qualificationImages;
    }

    public List<String> getQualityImages() {
        return qualityImages;
    }

    public void setQualityImages(List<String> qualityImages) {
        this.qualityImages = qualityImages;
    }

    public String getIntroduce() {
        return introduce;
    }

    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }
}
