package com.ddmc.kanban.client;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */

import com.ddmc.kanban.client.xingruan.config.feign.XingRuanReadConfiguration;
import com.ddmc.kanban.request.DataLoginRequestVo;
import com.ddmc.kanban.response.DataLoginResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Component
@FeignClient(name = "xingruan", url = "http://gmm.xingruan.net/basic/json",
        configuration = XingRuanReadConfiguration.class)
public interface XingRuanClient {

    @RequestMapping(value = "/GetLoginInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    DataLoginResponseVo GetLoginInfo(@RequestBody DataLoginRequestVo dataLoginRequestVo) throws Exception;
}
