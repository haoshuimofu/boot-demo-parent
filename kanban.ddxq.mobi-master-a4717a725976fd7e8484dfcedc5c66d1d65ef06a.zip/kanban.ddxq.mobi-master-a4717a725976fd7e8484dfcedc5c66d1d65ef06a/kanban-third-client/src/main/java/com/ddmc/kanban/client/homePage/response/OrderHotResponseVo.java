package com.ddmc.kanban.client.homePage.response;

import java.io.Serializable;
import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/22
 * @summary
 */
public class OrderHotResponseVo implements Serializable {

    /**
     * 总个数
     */
    private Integer total;

    /**
     * 经纬度对象
     */
    private List<Point> point;

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }

    public List<Point> getPoint() {
        return point;
    }

    public void setPoint(List<Point> point) {
        this.point = point;
    }
}
