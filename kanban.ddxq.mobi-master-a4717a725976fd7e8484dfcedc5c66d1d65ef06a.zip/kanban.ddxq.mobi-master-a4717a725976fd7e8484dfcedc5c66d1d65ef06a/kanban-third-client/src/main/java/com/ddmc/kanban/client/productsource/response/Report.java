package com.ddmc.kanban.client.productsource.response;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary
 */
public class Report {

    private String finishTime;
    private String purchaseFinishTime;


    public String getFinishTime() {
        return finishTime;
    }

    public void setFinishTime(String finishTime) {
        this.finishTime = finishTime;
    }

    public String getPurchaseFinishTime() {
        return purchaseFinishTime;
    }

    public void setPurchaseFinishTime(String purchaseFinishTime) {
        this.purchaseFinishTime = purchaseFinishTime;
    }
}
