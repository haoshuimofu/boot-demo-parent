package com.ddmc.kanban.client.personlicense.config.feign;

import feign.Request;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
@Configuration
public class PersonLicenseWriteConfiguration {


    @Bean
    @Scope("prototype")
    Request.Options feignOptions() {
        return new Request.Options(10 * 1000, 10 * 1000);
    }
}
