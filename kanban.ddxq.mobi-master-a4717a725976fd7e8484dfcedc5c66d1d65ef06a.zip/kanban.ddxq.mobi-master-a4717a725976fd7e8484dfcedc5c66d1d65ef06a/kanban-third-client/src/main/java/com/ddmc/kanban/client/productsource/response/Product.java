package com.ddmc.kanban.client.productsource.response;

/**
 * @author wangbo
 * @data 2019/3/19
 * @summary 商品信息
 */
public class Product {

    /**
     * 商品名称
     */
    private String name;
    /**
     * 小图片地址
     */
    private String smallImage;
    /**
     * 开始时间
     */
    private String releaseDate;
    /**
     * 逾期时间
     */
    private String expiryDate;
    /**
     * 批次号
     */
    private String batch;
    /**
     * 供应商名称
     */
    private String vendorName;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSmallImage() {
        return smallImage;
    }

    public void setSmallImage(String smallImage) {
        this.smallImage = smallImage;
    }

    public String getReleaseDate() {
        return releaseDate;
    }

    public void setReleaseDate(String releaseDate) {
        this.releaseDate = releaseDate;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
}
