package com.ddmc.kanban.client.xingruan.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
public class DataLoginResponseVo {

    @JsonProperty("GetLoginInfoResult")
    private Integer getLoginInfoResult;
    private Info info;

    public Info getInfo() {

        return info;
    }

    public void setInfo(Info info) {
        this.info = info;
    }

    public Integer getGetLoginInfoResult() {
        return getLoginInfoResult;
    }

    public void setGetLoginInfoResult(Integer getLoginInfoResult) {
        this.getLoginInfoResult = getLoginInfoResult;
    }
}
