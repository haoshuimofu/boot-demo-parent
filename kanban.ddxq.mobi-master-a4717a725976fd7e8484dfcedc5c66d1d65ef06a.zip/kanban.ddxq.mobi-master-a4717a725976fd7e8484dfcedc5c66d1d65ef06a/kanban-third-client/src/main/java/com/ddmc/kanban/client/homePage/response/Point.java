package com.ddmc.kanban.client.homePage.response;

import java.io.Serializable;

/**
 * @author wangbo
 * @data 2019/3/22
 * @summary
 */
public class Point implements Serializable {
    /**
     * 经度
     */
    private Double lng;
    /**
     * 纬度
     */
    private Double lat;
    /**
     * 个数
     */
    private Integer count;

    public Double getLng() {
        return lng;
    }

    public void setLng(Double lng) {
        this.lng = lng;
    }

    public Double getLat() {
        return lat;
    }

    public void setLat(Double lat) {
        this.lat = lat;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }
}
