package com.ddmc.kanban.client.personlicense.response;

import java.io.Serializable;
import java.util.List;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
public class StationUserResponseVo implements Serializable {

    /**
     * 总计人数
     */
    private String count;

    /**
     * 没有健康证人数
     */
    private String noHealthAuth;

    /**
     * 健康证过期人数
     */
    private String expiredHealthNumber;

    /**
     * 用户对象集合
     */
    private List<User> list;

    public String getCount() {
        return count;
    }

    public void setCount(String count) {
        this.count = count;
    }

    public String getNoHealthAuth() {
        return noHealthAuth;
    }

    public void setNoHealthAuth(String noHealthAuth) {
        this.noHealthAuth = noHealthAuth;
    }

    public String getExpiredHealthNumber() {
        return expiredHealthNumber;
    }

    public void setExpiredHealthNumber(String expiredHealthNumber) {
        this.expiredHealthNumber = expiredHealthNumber;
    }

    public List<User> getList() {
        return list;
    }

    public void setList(List<User> list) {
        this.list = list;
    }
}
