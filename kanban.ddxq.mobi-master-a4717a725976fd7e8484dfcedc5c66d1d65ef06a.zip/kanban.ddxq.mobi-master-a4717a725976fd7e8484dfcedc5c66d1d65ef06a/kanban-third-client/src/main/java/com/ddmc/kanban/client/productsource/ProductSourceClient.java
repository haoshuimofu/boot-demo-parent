package com.ddmc.kanban.client.productsource;

import com.ddmc.kanban.client.personlicense.config.feign.PersonLicenseReadConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * @author wangbo
 * @data 2019/3/18
 * @summary
 */
@Component
@FeignClient(name = "productsource", url = "http://maicai.api.x.dingdongxiaoqu.com/productApi",
        configuration = PersonLicenseReadConfiguration.class)
public interface ProductSourceClient {

    /**
     * 商品溯源
     *
     * @param productId 产品id
     * @param batch     批次号
     * @return
     * @throws Exception
     */
    @RequestMapping(value = "/Source", method = RequestMethod.GET)
    String source(@RequestParam(name = "product_id") String productId, @RequestParam(name = "batch") String batch) throws Exception;
}
