package com.ddmc.kanban.client.homePage;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */

import com.ddmc.kanban.client.homePage.feign.HomePageReadConfiguration;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Component
@FeignClient(name = "homepage", url = "http://admin.a.dingdongxiaoqu.com/order/hotMap",
        configuration = HomePageReadConfiguration.class)
public interface HomePageClient {

    @RequestMapping(value = "/getOrderHotMap", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
    String getOrderHotMap() throws Exception;
}
