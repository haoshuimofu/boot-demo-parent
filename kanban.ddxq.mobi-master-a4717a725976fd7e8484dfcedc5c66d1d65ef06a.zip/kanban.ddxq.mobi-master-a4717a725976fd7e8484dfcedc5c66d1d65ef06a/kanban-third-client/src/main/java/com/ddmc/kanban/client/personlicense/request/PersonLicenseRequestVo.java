package com.ddmc.kanban.client.personlicense.request;

import javax.ws.rs.QueryParam;
import java.io.Serializable;

/**
 * @author wangbo
 * @data 2019/3/20
 * @summary
 */
public class PersonLicenseRequestVo implements Serializable {

    @QueryParam("app_id")
    private String appId;
    @QueryParam("sign")
    private String sign;
    @QueryParam(value = "area")
    private String area;

    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    public String getSign() {
        return sign;
    }

    public void setSign(String sign) {
        this.sign = sign;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }
}
