#### 支付服务工程
1、module介绍
      
      {领域}-entity：实体module，以request、response为主，定义数据实体结构，为client和service引用
      {领域}-service：领域服务工程，部署后提供对应领域服务
      {领域}-client：领域服务客户端，上游工程可以引用该工程，调用里面提供的服务客户端接口，获取“{领域}-service”的处理结果
      
2、{领域}-service目录介绍

      config:  配置信息，通常放置 @Configuration注解的类
      constant：放置常量，其中ErrorCodeConstants定义了错误常量（错误码与错误信息，错误信息尽量对C\B端用户友好可读，而非对程序员友好）
      controller：controller放置的地方
      controller/client：直接对外提供服务的接口，比如app调用，通常由网关路由
      controller/manage：内部服务间调用的接口
      dao： DAO层放置的地方
      service：service层放置的地方
      
3、约定，参考见“{领域}-service”module
      
      错误码（本工程中统一在 ErrorCodeConstants 定义）长度九位，前三位为服务名，全公司统一管理，后六位由应用自己定义编码
      对外提供服务（controller/client）URL统一约定：api/版本/领域名
      对内提供服务（controller/manage）URL统一约定：manage/领域名
      
      controller以HTTP协议POST方法提供服务
      请求统一格式封装，见：com.ddmc.core.view.RequestBaseVo，纯业务参数封装在param属性中
      返回统一格式封装，见：com.ddmc.core.view.ResponseBaseVo，纯业务结果封装在datas属性中
      Dao操作以Model为出入参；controller以“{领域}-entity”中定义的request、response分别为入、出参，简单的单个入、出参如String、Integer之类的除外
      
      备注：错误码定义
        http://git.ddxq.mobi/docs/dev_team/blob/master/backend/微服务建设/错误编码前三位-服务标识-约定.md
      
4、接口自测方法

      1、安装Postman
      2、打开Postman，选择POST方法，填写接口URL
      3、点击请求区域的Body tab，选择"raw"、 content-type 选择 "JSON(application/json)"
      4、如果有入参如下填写，eg：
                {
                    "appKey":"IOS1213123214",
                    "sign":"sign",
                    "timestamp": 1231241423423,
                    "param":{"id":"59967f1fdd9087a03a8e5444"}
                }
      5、点击Send 按钮 

5、有开发自己的测试环境下，开发之间联测
    
      多个程序猿，多个服务工程并行开发，比如A1、A2、A3猿本地开发a工程、B1、B2猿本地开发b工程，a、b还依赖c、d、e等工程，c、d、e本次迭代没有修改运行在相对稳定研发测试环境。
      多个工程的研发程序员直接联调，依赖一个或多个其他未完成接口、或外部接口没有测试环境且不方便使用对方生产环境、或者多猿联调且依赖其他稳定环境的接口
      为了避免写死代码而联调，发布到生产的风险
      为了减少频繁发布开发测试环境的服务影响其他人，提高效率
      为了减少远程调试打断点，可能会影响其他程序猿的测试
      事先需要准备好postman、fiddler
          1、在IDEA之类的开发工具中，设置要测试的工程中的bootstrap.xml
                    spring.cloud.zookeeper.discovery.register为false
          2、如果下游接口没有开发好，上游开发好要自测，可以先根据下游的接口准备报文本地文件
          3、ideal设置jvm参数，在"菜单"--> run --> edit configurations...  
                    给启动类添加jvm参数（根据fiddler所在的ip和监听端口而定）：   -DproxySet=true -DproxyHost=127.0.0.1 -DproxyPort=8888
          4、fiddler拦截设置
                    下游未开发好接口，那么上游的程序猿根据下游预备提供接口在发布到开发测试环境后的URL，在fiddler中设置拦截，返回预先准备好的报文文件内容
                    下游接口开发好，下游程序猿IDEA启动服务，上游的程序猿根据下游预备提供的接口在发布到开发测试环境后的URL，在fiddler中设置拦截，将改URL请求转发的下游程序猿的本地应用程序对应接口URL
                    
      备注：远程调试在多人开发的情况下，经常会影响其他程序猿，建议联调用fiddler拦截转发，本地测试

6、各环境关于配置中心客户端设置

      a、开发环境：idea里面 run->edit configurations->对应的configuration->environment->VM options 中添加env、cluster。eg: -Denv=DEV -Dapollo.cluster=cluster1
      b、测试环境、生产环境如下面的章节7中建议设置
      
7、apollo客户端配置
      <table width="2958" border="1" cellpadding="0" cellspacing="0" >
       <tr>
        <th></th>
        <th>Java System Property</th>
        <th>application.properties</th>
        <th>bootstrap.properties</th>
        <th>/META-INF/app.properties</th>
        <th>server.properties</th>
        <th>OS环境变量</th>
        <th>apollo-env.properties</th>
        <th>默认</th>
        <th>测试环境建议</th>
        <th>生产环境建议</th>
        <th>是否必配</th>
       </tr>
       <tr>
        <td><b>app.id</b></td>
        <td>-Dapp.id=YOUR-APP-ID</td>
        <td>app.id=YOUR-APP-ID</td>
        <td>app.id=YOUR-APP-ID</td>
        <td>app.id=YOUR-APP-ID</td>
        <td></td>
        <td></td>
        <td></td>
        <td></td>
        <td>bootstrap.properties</td>
        <td>bootstrap.properties</td>
        <td>是</td>
       </tr>
       <tr>
        <td><b>Apollo Meta Server</b></td>
        <td>-Dapollo.meta=config-service-url 或者 -D${env}_meta</td>
        <td>apollo.meta=</td>
        <td>apollo.meta=</td>
        <td>apollo.meta=</td>
        <td>apollo.meta=</td>
        <td>APOLLO_META 或者 ${ENV}_META</td>
        <td>dev.meta=http://x.x.x.x:8080<br/>fat.meta=http://apollo.fat.xxx.com<br/>uat.meta=http://apollo.uat.xxx.com<br/>pro.meta=http://apollo.xxx.com</td>
        <td></td>
        <td>bootstrap.properties</td>
        <td>bootstrap.properties</td>
        <td>是</td>
       </tr>
       <tr>
        <td><b>本地缓存路径</b></td>
        <td>-Dapollo.cacheDir=自定义目录</td>
        <td>apollo.cacheDir=自定义目录</td>
        <td>apollo.cacheDir=自定义目录</td>
        <td></td>
        <td>apollo.cacheDir=自定义目录</td>
        <td>APOLLO_CACHEDIR</td>
        <td></td>
        <td>Mac/Linux:/opt/data/{appId}/config-cache<br/>Windows: C:\opt\data\{appId}\config-cache<br/>注意java进程对改目录的读写权限</td>
        <td>Java System Property</td>
        <td>默认</td>
        <td>是</td>
       </tr>
       <tr>
        <td><b>Environment</b></td>
        <td>-Denv=</td>
        <td></td>
        <td></td>
        <td></td>
        <td>env=</td>
        <td>ENV</td>
        <td></td>
        <td></td>
        <td>Java System Property</td>
        <td>Java System Property</td>
        <td>否</td>
       </tr>
       <tr>
        <td><b>Cluster</b></td>
        <td>-Dapollo.cluster=</td>
        <td>apollo.cluster=</td>
        <td>apollo.cluster=</td>
        <td></td>
        <td>apollo.cluster=</td>
        <td></td>
        <td></td>
        <td>default</td>
        <td>Java System Property</td>
        <td>默认</td>
        <td>否</td>
       </tr>
      </table>
   
     备注：
         1、server.properties对于Mac/Linux，文件位置为/opt/settings/server.properties； 对于Windows，文件位置为C:\opt\settings\server.properties
         2、env枚举：DEV、FAT、UAT、PRO
