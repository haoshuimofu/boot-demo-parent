package com.ddmc.kanban.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @Author chenkai
 * @Create 2019-03-19 10:50
 */
public class YestodayQualitySummaryVo {
	
	@JsonProperty("totalCount")
	private Integer totalCount;
	
	@JsonProperty("unQualityCount")
	private Integer unQualityCount;
	
	@JsonProperty("unQualifiedCount")
	private Integer unQualifiedCount;

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public Integer getUnQualityCount() {
		return unQualityCount;
	}

	public void setUnQualityCount(Integer unQualityCount) {
		this.unQualityCount = unQualityCount;
	}

	public Integer getUnQualifiedCount() {
		return unQualifiedCount;
	}

	public void setUnQualifiedCount(Integer unQualifiedCount) {
		this.unQualifiedCount = unQualifiedCount;
	}
	
	
}
