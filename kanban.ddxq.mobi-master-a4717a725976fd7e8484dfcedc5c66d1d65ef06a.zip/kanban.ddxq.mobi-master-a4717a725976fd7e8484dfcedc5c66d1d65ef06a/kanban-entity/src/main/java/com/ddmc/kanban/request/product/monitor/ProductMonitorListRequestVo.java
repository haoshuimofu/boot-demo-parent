package com.ddmc.kanban.request.product.monitor;

import com.ddmc.kanban.request.base.BasePageRequest;

/**
 * 临期过期商品列表页分页请求
 *
 * @Author wude
 * @Create 2019-03-20 18:21
 */
public class ProductMonitorListRequestVo extends BasePageRequest {
    private Integer type;

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}