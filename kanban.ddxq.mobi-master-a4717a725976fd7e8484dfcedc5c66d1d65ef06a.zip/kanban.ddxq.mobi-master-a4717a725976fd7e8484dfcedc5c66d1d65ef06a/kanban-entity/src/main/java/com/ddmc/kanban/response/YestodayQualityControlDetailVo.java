package com.ddmc.kanban.response;

import java.math.BigDecimal;

import com.fasterxml.jackson.annotation.JsonProperty;

public class YestodayQualityControlDetailVo {

	@JsonProperty("productId")
	private Long productId;

	@JsonProperty("productName")
	private String productName;

	@JsonProperty("planAmount")
	private String planAmount;

	@JsonProperty("realAmount")
	private String realAmount;

	@JsonProperty("settlementAmount")
	private String settlementAmount;

	@JsonProperty("samplingQuantity")
	private BigDecimal samplingQuantity;

	@JsonProperty("samplingRate")
	private BigDecimal samplingRate;

	@JsonProperty("sizeInconformity")
	private BigDecimal sizeInconformity;

	@JsonProperty("oneUnqualified")
	private BigDecimal oneUnqualified;

	@JsonProperty("twoUnqualified")
	private BigDecimal twoUnqualified;

	@JsonProperty("threeUnqualified")
	private BigDecimal threeUnqualified;

	@JsonProperty("fourUnqualified")
	private BigDecimal fourUnqualified;

	@JsonProperty("unqualifiedRate")
	private BigDecimal unqualifiedRate;

	@JsonProperty("cableTicket")
	private String cableTicket;

	@JsonProperty("ticketNumber")
	private String ticketNumber;

	@JsonProperty("qualityJudgment")
	private Integer qualityJudgment;

	@JsonProperty("receptionType")
	private Integer receptionType;

	@JsonProperty("inspector")
	private String inspector;

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getPlanAmount() {
		return planAmount;
	}

	public void setPlanAmount(String planAmount) {
		this.planAmount = planAmount;
	}

	public String getRealAmount() {
		return realAmount;
	}

	public void setRealAmount(String realAmount) {
		this.realAmount = realAmount;
	}

	public String getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(String settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public BigDecimal getSamplingQuantity() {
		return samplingQuantity;
	}

	public void setSamplingQuantity(BigDecimal samplingQuantity) {
		this.samplingQuantity = samplingQuantity;
	}

	public BigDecimal getSamplingRate() {
		return samplingRate;
	}

	public void setSamplingRate(BigDecimal samplingRate) {
		this.samplingRate = samplingRate;
	}

	public BigDecimal getSizeInconformity() {
		return sizeInconformity;
	}

	public void setSizeInconformity(BigDecimal sizeInconformity) {
		this.sizeInconformity = sizeInconformity;
	}

	public BigDecimal getOneUnqualified() {
		return oneUnqualified;
	}

	public void setOneUnqualified(BigDecimal oneUnqualified) {
		this.oneUnqualified = oneUnqualified;
	}

	public BigDecimal getTwoUnqualified() {
		return twoUnqualified;
	}

	public void setTwoUnqualified(BigDecimal twoUnqualified) {
		this.twoUnqualified = twoUnqualified;
	}

	public BigDecimal getThreeUnqualified() {
		return threeUnqualified;
	}

	public void setThreeUnqualified(BigDecimal threeUnqualified) {
		this.threeUnqualified = threeUnqualified;
	}

	public BigDecimal getFourUnqualified() {
		return fourUnqualified;
	}

	public void setFourUnqualified(BigDecimal fourUnqualified) {
		this.fourUnqualified = fourUnqualified;
	}

	public BigDecimal getUnqualifiedRate() {
		return unqualifiedRate;
	}

	public void setUnqualifiedRate(BigDecimal unqualifiedRate) {
		this.unqualifiedRate = unqualifiedRate;
	}

	public String getCableTicket() {
		return cableTicket;
	}

	public void setCableTicket(String cableTicket) {
		this.cableTicket = cableTicket;
	}

	public String getTicketNumber() {
		return ticketNumber;
	}

	public void setTicketNumber(String ticketNumber) {
		this.ticketNumber = ticketNumber;
	}

	public Integer getQualityJudgment() {
		return qualityJudgment;
	}

	public void setQualityJudgment(Integer qualityJudgment) {
		this.qualityJudgment = qualityJudgment;
	}

	public Integer getReceptionType() {
		return receptionType;
	}

	public void setReceptionType(Integer receptionType) {
		this.receptionType = receptionType;
	}

	public String getInspector() {
		return inspector;
	}

	public void setInspector(String inspector) {
		this.inspector = inspector;
	}

}
