package com.ddmc.kanban.response;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
public class CarInfo {

    //TODO 暂时不知道数据结构 先定义一个空对象
}
