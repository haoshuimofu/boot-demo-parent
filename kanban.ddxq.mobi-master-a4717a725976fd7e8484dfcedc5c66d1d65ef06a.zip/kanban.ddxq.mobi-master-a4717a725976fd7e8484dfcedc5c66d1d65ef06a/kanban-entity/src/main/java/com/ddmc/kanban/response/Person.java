package com.ddmc.kanban.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
public class Person {

    @JsonProperty("Company")
    private Company company;
    @JsonProperty("CompanyID")
    private Integer companyID;
    @JsonProperty("Dept")
    private Dept dept;
    @JsonProperty("DeptID")
    private Integer deptID;
    @JsonProperty("Mobile")
    private String mobile;
    @JsonProperty("Name")
    private String name;
    @JsonProperty("PersonID")
    private Integer personID;
    @JsonProperty("Sex")
    private Integer sex;

    public Company getCompany() {
        return company;
    }

    public void setCompany(Company company) {
        this.company = company;
    }

    public Integer getCompanyID() {
        return companyID;
    }

    public void setCompanyID(Integer companyID) {
        this.companyID = companyID;
    }

    public Dept getDept() {
        return dept;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }

    public Integer getDeptID() {
        return deptID;
    }

    public void setDeptID(Integer deptID) {
        this.deptID = deptID;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getPersonID() {
        return personID;
    }

    public void setPersonID(Integer personID) {
        this.personID = personID;
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }
}
