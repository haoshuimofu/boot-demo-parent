package com.ddmc.kanban.response.product.monitor;

/**
 * 商品临期过期监控总览返回VO
 *
 * @Author wude
 * @Create 2019-03-20 17:33
 */
public class ProductMonitorSummaryResponseVo {

    /**
     * 统计时间
     */
    private String countTime;
    /**
     * 监控SKU种类数
     */
    private int skuSum;
    /**
     * 临期商品数
     */
    private int expiringSum;
    /**
     * 过期商品数
     */
    private int expredSum;

    public String getCountTime() {
        return countTime;
    }

    public void setCountTime(String countTime) {
        this.countTime = countTime;
    }

    public int getSkuSum() {
        return skuSum;
    }

    public void setSkuSum(int skuSum) {
        this.skuSum = skuSum;
    }

    public int getExpiringSum() {
        return expiringSum;
    }

    public void setExpiringSum(int expiringSum) {
        this.expiringSum = expiringSum;
    }

    public int getExpredSum() {
        return expredSum;
    }

    public void setExpredSum(int expredSum) {
        this.expredSum = expredSum;
    }
}