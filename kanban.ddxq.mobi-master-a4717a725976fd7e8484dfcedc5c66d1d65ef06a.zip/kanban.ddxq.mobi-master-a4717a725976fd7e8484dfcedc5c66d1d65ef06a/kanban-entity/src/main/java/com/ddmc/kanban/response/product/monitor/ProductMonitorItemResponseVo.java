package com.ddmc.kanban.response.product.monitor;

/**
 * 临期过期商品监控列表页商品信息
 *
 * @Author wude
 * @Create 2019-03-20 17:42
 */
public class ProductMonitorItemResponseVo {

    private Integer storeId;
    private String storeName;
    private Integer productId;
    private String productName;
    private Integer total;

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public Integer getProductId() {
        return productId;
    }

    public void setProductId(Integer productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getTotal() {
        return total;
    }

    public void setTotal(Integer total) {
        this.total = total;
    }
}