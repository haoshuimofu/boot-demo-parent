package com.ddmc.kanban.request;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * @author wangbo
 * @data 2019/3/15
 * @summary
 */
public class DataLoginRequestVo {

    @JsonProperty("info")
    private RequestInfo requestInfo;

    public RequestInfo getRequestInfo() {
        return requestInfo;
    }

    public void setRequestInfo(RequestInfo requestInfo) {
        this.requestInfo = requestInfo;
    }
}

class RequestInfo{
    @JsonProperty("LogName")
    private String logName;
    @JsonProperty("LoginType")
    private Integer loginType;
    @JsonProperty("Password")
    private String password;

    public String getLogName() {
        return logName;
    }

    public void setLogName(String logName) {
        this.logName = logName;
    }

    public Integer getLoginType() {
        return loginType;
    }

    public void setLoginType(Integer loginType) {
        this.loginType = loginType;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
