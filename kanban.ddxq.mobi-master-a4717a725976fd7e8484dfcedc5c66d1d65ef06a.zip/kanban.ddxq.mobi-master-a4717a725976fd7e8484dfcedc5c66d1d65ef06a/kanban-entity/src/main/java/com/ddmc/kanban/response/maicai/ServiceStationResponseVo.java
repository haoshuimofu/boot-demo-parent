package com.ddmc.kanban.response.maicai;

/**
 * @author wangbo
 * @data 2019/3/21
 * @summary 服务站列表 从买菜后台获取
 */
public class ServiceStationResponseVo {

    /**
     * 服务站id
     */
    private String stationId;
    /**
     * 服务站名称
     */
    private String stationName;
    /**
     * 服务站地址
     */
    private String stationAddress;

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public String getStationName() {
        return stationName;
    }

    public void setStationName(String stationName) {
        this.stationName = stationName;
    }

    public String getStationAddress() {
        return stationAddress;
    }

    public void setStationAddress(String stationAddress) {
        this.stationAddress = stationAddress;
    }
}
