package com.ddmc.kanban.response;

import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
* <p>Description: </p>    
* @author chenkai  
* @date 2019年3月19日
 */
public class YestodayQualityControlVo {
	
	@JsonProperty("qualityId")
	private Long qualityId;
	
	@JsonProperty("productName")
	private String productName;
	
	@JsonProperty("purchaseId")
	private Long purchaseId;
	
	@JsonProperty("qualityJudgment")
	private Integer qualityJudgment;
	
	@JsonProperty("receptionType")
	private Integer receptionType;
	
	@JsonProperty("qualityTime")
	private String qualityTime;

	public Long getQualityId() {
		return qualityId;
	}

	public void setQualityId(Long qualityId) {
		this.qualityId = qualityId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Long getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(Long purchaseId) {
		this.purchaseId = purchaseId;
	}

	public Integer getQualityJudgment() {
		return qualityJudgment;
	}

	public void setQualityJudgment(Integer qualityJudgment) {
		this.qualityJudgment = qualityJudgment;
	}

	public Integer getReceptionType() {
		return receptionType;
	}

	public void setReceptionType(Integer receptionType) {
		this.receptionType = receptionType;
	}

	public String getQualityTime() {
		return qualityTime;
	}

	public void setQualityTime(String qualityTime) {
		this.qualityTime = qualityTime;
	}
	
	
	
}
