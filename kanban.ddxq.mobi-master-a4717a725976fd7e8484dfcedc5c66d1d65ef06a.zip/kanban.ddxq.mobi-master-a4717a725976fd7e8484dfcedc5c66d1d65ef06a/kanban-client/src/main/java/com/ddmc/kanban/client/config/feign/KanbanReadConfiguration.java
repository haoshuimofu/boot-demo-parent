package com.ddmc.kanban.client.config.feign;

import feign.Request;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

/**
 * 单个feign 客户端设置--不启用熔断模式
 */
@Configuration
public class KanbanReadConfiguration {

    /**
     * 如果想覆盖默认配置，需要这样配置
     *
     * @return
     */
    @Bean
    @Scope("prototype")
    Request.Options feignOptions() {
        return new Request.Options(10 * 1000, 10 * 1000);
    }
}
